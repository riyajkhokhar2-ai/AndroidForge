package com.example

import android.os.Bundle
import android.widget.Toast
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.delay
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.AddShoppingCart
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Bill
import com.example.ui.CartState
import com.example.ui.MainViewModel
import com.example.ui.Screen
import com.example.ui.dialogs.ReceiptDetailDialog
import com.example.ui.screens.BillHistoryScreen
import com.example.ui.screens.BillingScreen
import com.example.ui.screens.CustomersScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.ProductsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MMartTheme
import kotlinx.coroutines.launch
import java.io.File

data class NavItem(
    val screen: Screen,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings by viewModel.settings.collectAsState()
            val currentScreen by viewModel.currentScreen.collectAsState()
            val cartState by viewModel.cartState.collectAsState()
            val toastMessage by viewModel.toastMessage.collectAsState()

            val snackbarHostState = remember { SnackbarHostState() }
            val coroutineScope = rememberCoroutineScope()
            val context = LocalContext.current

            // Active Bill Viewing Dialog
            var viewingBill by remember { mutableStateOf<Bill?>(null) }

            // Handle Toast messages
            LaunchedEffect(toastMessage) {
                toastMessage?.let { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    viewModel.clearToast()
                }
            }

            // Back button handling: return to dashboard if on sub-screen
            BackHandler(enabled = currentScreen != Screen.Dashboard) {
                viewModel.navigateTo(Screen.Dashboard)
            }

            MMartTheme(darkTheme = settings.isDarkMode) {
                var showIntro by remember { mutableStateOf(savedInstanceState == null) }
                if (showIntro) {
                    MmartProIntro(onFinished = { showIntro = false })
                } else {
                val configuration = LocalConfiguration.current
                val isTabletOrExpanded = configuration.screenWidthDp >= 600

                val navItems = listOf(
                    NavItem(Screen.Dashboard, Icons.Filled.Dashboard, Icons.Outlined.Dashboard, "nav_dashboard"),
                    NavItem(Screen.Billing, Icons.Filled.AddShoppingCart, Icons.Outlined.AddShoppingCart, "nav_billing"),
                    NavItem(Screen.Products, Icons.Filled.Inventory2, Icons.Outlined.Inventory2, "nav_products"),
                    NavItem(Screen.Customers, Icons.Filled.People, Icons.Outlined.People, "nav_khata"),
                    NavItem(Screen.History, Icons.Filled.History, Icons.Outlined.History, "nav_history"),
                    NavItem(Screen.Settings, Icons.Filled.Settings, Icons.Outlined.Settings, "nav_settings")
                )

                // Bill Detail & Reprint Dialog
                if (viewingBill != null) {
                    val bill = viewingBill!!
                    val billItems = viewModel.repository.decodeBillItems(bill.itemsJson)
                    ReceiptDetailDialog(
                        bill = bill,
                        items = billItems,
                        settings = settings,
                        onDismiss = { viewingBill = null }
                    )
                }

                Row(modifier = Modifier.fillMaxSize()) {
                    // NavigationRail for Tablets
                    if (isTabletOrExpanded) {
                        NavigationRail(
                            modifier = Modifier.fillMaxHeight(),
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            navItems.forEach { item ->
                                val isSelected = currentScreen == item.screen
                                NavigationRailItem(
                                    selected = isSelected,
                                    onClick = { viewModel.navigateTo(item.screen) },
                                    icon = {
                                        RenderNavIcon(item, isSelected, cartState)
                                    },
                                    label = { Text(item.screen.titleEn, fontSize = 11.sp) },
                                    modifier = Modifier.testTag(item.testTag)
                                )
                            }
                        }
                    }

                    Scaffold(
                        modifier = Modifier.weight(1f),
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        topBar = {
                            CenterAlignedTopAppBar(
                                title = {
                                    Text(
                                        text = "${settings.shopName} • ${currentScreen.titleEn}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                },
                                actions = {
                                    if (currentScreen != Screen.Billing) {
                                        IconButton(
                                            onClick = { viewModel.navigateTo(Screen.Billing) },
                                            modifier = Modifier.testTag("topbar_billing_btn")
                                        ) {
                                            RenderNavIcon(
                                                NavItem(Screen.Billing, Icons.Filled.AddShoppingCart, Icons.Outlined.AddShoppingCart, ""),
                                                false,
                                                cartState
                                            )
                                        }
                                    }
                                    if (currentScreen != Screen.Settings) {
                                        IconButton(
                                            onClick = { viewModel.navigateTo(Screen.Settings) },
                                            modifier = Modifier.testTag("topbar_settings_btn")
                                        ) {
                                            Icon(Icons.Default.Settings, contentDescription = "Settings")
                                        }
                                    }
                                },
                                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                    containerColor = MaterialTheme.colorScheme.surface
                                )
                            )
                        },
                        bottomBar = {
                            if (!isTabletOrExpanded) {
                                NavigationBar(
                                    containerColor = MaterialTheme.colorScheme.surface,
                                    tonalElevation = 6.dp
                                ) {
                                    navItems.forEach { item ->
                                        val isSelected = currentScreen == item.screen
                                        NavigationBarItem(
                                            selected = isSelected,
                                            onClick = { viewModel.navigateTo(item.screen) },
                                            icon = {
                                                RenderNavIcon(item, isSelected, cartState)
                                            },
                                            label = {
                                                Text(
                                                    text = item.screen.titleEn,
                                                    fontSize = 10.sp,
                                                    maxLines = 1,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                                )
                                            },
                                            modifier = Modifier.testTag(item.testTag)
                                        )
                                    }
                                }
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when (currentScreen) {
                                Screen.Dashboard -> DashboardScreen(
                                    viewModel = viewModel,
                                    onOpenBillDetails = { viewingBill = it }
                                )
                                Screen.Billing -> BillingScreen(
                                    viewModel = viewModel,
                                    onBillGenerated = { bill, file ->
                                        viewingBill = bill
                                    }
                                )
                                Screen.Products -> ProductsScreen(
                                    viewModel = viewModel
                                )
                                Screen.Customers -> CustomersScreen(
                                    viewModel = viewModel
                                )
                                Screen.History -> BillHistoryScreen(
                                    viewModel = viewModel,
                                    onOpenBillDetails = { viewingBill = it }
                                )
                                Screen.Inventory -> InventoryScreen(
                                    viewModel = viewModel
                                )
                                Screen.Settings -> SettingsScreen(
                                    viewModel = viewModel
                                )
                            }
                        }
                    }
                }
                }
            }
        }
    }
}

@Composable
private fun RenderNavIcon(item: NavItem, isSelected: Boolean, cartState: CartState) {
    val icon = if (isSelected) item.selectedIcon else item.unselectedIcon
    if (item.screen == Screen.Billing && cartState.items.isNotEmpty()) {
        BadgedBox(
            badge = {
                Badge {
                    Text(cartState.items.size.toString())
                }
            }
        ) {
            Icon(
                imageVector = icon,
                contentDescription = item.screen.titleEn,
                modifier = Modifier.size(24.dp)
            )
        }
    } else {
        Icon(
            imageVector = icon,
            contentDescription = item.screen.titleEn,
            modifier = Modifier.size(24.dp)
        )
    }
}


/** Offline animated launch intro. Uses native Compose graphics and a short system audio cue. */
@Composable
private fun MmartProIntro(onFinished: () -> Unit) {
    var stage by remember { mutableStateOf(0) }
    var skipped by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(650)
        stage = 1
        delay(1050)
        stage = 2
        try {
            val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 48)
            tone.startTone(ToneGenerator.TONE_PROP_ACK, 180)
            delay(230)
            tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 150)
            delay(180)
            tone.release()
        } catch (_: Exception) { }
        delay(1650)
        if (!skipped) onFinished()
    }

    val titleScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (stage >= 2) 1f else 0.72f,
        animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.62f),
        label = "brandScale"
    )
    val titleAlpha by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (stage >= 2) 1f else 0f,
        animationSpec = androidx.compose.animation.core.tween(650),
        label = "brandAlpha"
    )

    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF07152F), Color(0xFF142B58), Color(0xFF321B62), Color(0xFF08152D)))
        ), contentAlignment = Alignment.Center
    ) {
        Box(Modifier.align(Alignment.TopStart).padding(start = 28.dp, top = 105.dp).size(110.dp)
            .background(Color(0x333A8DFF), RoundedCornerShape(60.dp)))
        Box(Modifier.align(Alignment.BottomEnd).padding(end = 22.dp, bottom = 120.dp).size(145.dp)
            .background(Color(0x3327D7C4), RoundedCornerShape(80.dp)))

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
        ) {
            Text("✦  ✦  ✦", color = Color(0xFF7EDBFF), fontSize = 20.sp, letterSpacing = 8.sp)
            Spacer(Modifier.height(22.dp))
            Box(Modifier.fillMaxWidth().height(190.dp).padding(horizontal = 8.dp), contentAlignment = Alignment.Center) {
                Column(
                    modifier = Modifier.fillMaxWidth(0.88f).height(154.dp)
                        .background(Brush.verticalGradient(listOf(Color(0xFF244C83), Color(0xFF10294D))), RoundedCornerShape(18.dp))
                        .border(1.dp, Color(0x887BCBFF), RoundedCornerShape(18.dp)).padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("M MART • FRESH & DAILY", color = Color.White, fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("🥫", "🍎", "🥛", "🍞", "🧃").forEachIndexed { index, item ->
                            Box(Modifier.weight(1f).height(68.dp).background(
                                listOf(Color(0xFF315F9C), Color(0xFF386F8C), Color(0xFF34588A), Color(0xFF4B5D91), Color(0xFF286D83))[index],
                                RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) {
                                Text(item, fontSize = 25.sp)
                            }
                        }
                    }
                }
                Text("🛒", fontSize = 76.sp, modifier = Modifier.align(Alignment.BottomCenter)
                    .scale(if (stage >= 1) 1f else 0.72f))
            }
            Spacer(Modifier.height(18.dp))
            Text("M MART PRO", modifier = Modifier.alpha(titleAlpha).scale(titleScale), color = Color.White,
                fontSize = 34.sp, fontWeight = FontWeight.Black, letterSpacing = 2.2.sp, textAlign = TextAlign.Center)
            Text("SMART BILLING  •  SMART BUSINESS", modifier = Modifier.alpha(titleAlpha), color = Color(0xFF9EDCFF),
                fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(30.dp))
            Text("Your store. Smarter every day.", color = Color(0xFFCBD8F0), fontSize = 13.sp, textAlign = TextAlign.Center)
        }
        androidx.compose.material3.TextButton(onClick = { skipped = true; onFinished() },
            modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)) {
            Text("SKIP INTRO  ›", color = Color.White, fontWeight = FontWeight.Bold)
        }
        Text("M MART PRO", color = Color(0x88FFFFFF), fontSize = 10.sp, letterSpacing = 2.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 22.dp))
    }
}
