package com.example.util

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.ShopSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ShopSettingsManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("mmart_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<ShopSettings> = _settings.asStateFlow()

    private fun loadSettings(): ShopSettings {
        return ShopSettings(
            shopName = prefs.getString("shop_name", "M Mart Pro") ?: "M Mart Pro",
            tagline = prefs.getString("tagline", "Supermarket & Daily Needs") ?: "Supermarket & Daily Needs",
            address = prefs.getString("address", "Shop No. 12, Main Market Road") ?: "Shop No. 12, Main Market Road",
            phone = prefs.getString("phone", "+91 98765 43210") ?: "+91 98765 43210",
            gstin = prefs.getString("gstin", "27AAAAA0000A1Z5") ?: "27AAAAA0000A1Z5",
            upiId = prefs.getString("upi_id", "mmartpro@upi") ?: "mmartpro@upi",
            receiptFooter = prefs.getString("receipt_footer", "धन्यवाद! Thank you for shopping with us! Please visit again.")
                ?: "धन्यवाद! Thank you for shopping with us! Please visit again.",
            isDarkMode = prefs.getBoolean("dark_mode", false),
            isHindiDefault = prefs.getBoolean("hindi_default", false),
            autoPrint = prefs.getBoolean("auto_print", false)
        )
    }

    fun saveSettings(updated: ShopSettings) {
        prefs.edit()
            .putString("shop_name", updated.shopName)
            .putString("tagline", updated.tagline)
            .putString("address", updated.address)
            .putString("phone", updated.phone)
            .putString("gstin", updated.gstin)
            .putString("upi_id", updated.upiId)
            .putString("receipt_footer", updated.receiptFooter)
            .putBoolean("dark_mode", updated.isDarkMode)
            .putBoolean("hindi_default", updated.isHindiDefault)
            .putBoolean("auto_print", updated.autoPrint)
            .apply()
        _settings.value = updated
    }
}
