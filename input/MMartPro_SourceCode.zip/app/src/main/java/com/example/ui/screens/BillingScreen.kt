package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Bill
import com.example.data.model.CartItem
import com.example.data.model.Customer
import com.example.data.model.Product
import com.example.ui.MainViewModel
import com.example.ui.components.CameraScannerView
import com.example.ui.dialogs.AddCustomerDialog
import com.example.ui.dialogs.AddEditProductDialog
import com.example.util.BillPrintHelper
import com.example.util.PdfReceiptGenerator
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BillingScreen(
    viewModel: MainViewModel,
    onBillGenerated: (Bill, File) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cart by viewModel.cartState.collectAsState()
    val allProducts by viewModel.products.collectAsState()
    val allCustomers by viewModel.customers.collectAsState()

    var isCameraScannerOpen by remember { mutableStateOf(false) }
    var manualBarcodeInput by remember { mutableStateOf("") }
    var productSearchInput by remember { mutableStateOf("") }
    var isSearchDropdownOpen by remember { mutableStateOf(false) }

    var isCustomerSelectOpen by remember { mutableStateOf(false) }
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var showAddProductDialog by remember { mutableStateOf(false) }
    var scannedBarcodeForNewProduct by remember { mutableStateOf<String?>(null) }

    var discountInput by remember { mutableStateOf("") }
    var amountPaidInput by remember { mutableStateOf("") }

    // Dialogs
    if (showAddCustomerDialog) {
        AddCustomerDialog(
            onSave = { newCust ->
                viewModel.saveCustomer(newCust) {
                    viewModel.selectCustomer(newCust)
                    showAddCustomerDialog = false
                }
            },
            onDismiss = { showAddCustomerDialog = false }
        )
    }

    if (showAddProductDialog) {
        AddEditProductDialog(
            prefilledBarcode = scannedBarcodeForNewProduct,
            onSave = { newProd ->
                viewModel.saveProduct(newProd) {
                    viewModel.addProductToCart(newProd)
                    showAddProductDialog = false
                    scannedBarcodeForNewProduct = null
                }
            },
            onDismiss = {
                showAddProductDialog = false
                scannedBarcodeForNewProduct = null
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Barcode Scanner Controls (Camera Viewfinder + Manual Entry Row)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Header with Camera Toggle Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "बारकोड स्कैनर / Barcode Scanner",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "CameraX & ML Kit द्वारा संचालित",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = { isCameraScannerOpen = !isCameraScannerOpen },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isCameraScannerOpen) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("toggle_camera_scanner_btn")
                        ) {
                            Icon(
                                imageVector = if (isCameraScannerOpen) Icons.Default.Clear else Icons.Default.CameraAlt,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isCameraScannerOpen) "Hide / बंद" else "Scan / कैमरा")
                        }
                    }

                    // Live Camera View
                    AnimatedVisibility(
                        visible = isCameraScannerOpen,
                        enter = expandVertically(),
                        exit = shrinkVertically()
                    ) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            CameraScannerView(
                                onBarcodeScanned = { barcode ->
                                    viewModel.onBarcodeScanned(barcode) { notFoundBarcode ->
                                        scannedBarcodeForNewProduct = notFoundBarcode
                                        showAddProductDialog = true
                                    }
                                },
                                onClose = { isCameraScannerOpen = false }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Manual Barcode Input
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = manualBarcodeInput,
                            onValueChange = { manualBarcodeInput = it },
                            label = { Text("बारकोड दर्ज करें / Enter Barcode") },
                            placeholder = { Text("e.g. 8901058000416") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    if (manualBarcodeInput.isNotBlank()) {
                                        viewModel.onBarcodeScanned(manualBarcodeInput.trim()) { nf ->
                                            scannedBarcodeForNewProduct = nf
                                            showAddProductDialog = true
                                        }
                                        manualBarcodeInput = ""
                                    }
                                }
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("manual_barcode_input")
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        FilledTonalButton(
                            onClick = {
                                if (manualBarcodeInput.isNotBlank()) {
                                    viewModel.onBarcodeScanned(manualBarcodeInput.trim()) { nf ->
                                        scannedBarcodeForNewProduct = nf
                                        showAddProductDialog = true
                                    }
                                    manualBarcodeInput = ""
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .height(56.dp)
                                .testTag("add_manual_barcode_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("जोड़ें / Add")
                        }
                    }
                }
            }
        }

        // Product Search & Auto-Suggest
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    OutlinedTextField(
                        value = productSearchInput,
                        onValueChange = {
                            productSearchInput = it
                            isSearchDropdownOpen = it.isNotBlank()
                        },
                        label = { Text("उत्पाद खोजें / Search Item by Name") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (productSearchInput.isNotBlank()) {
                                IconButton(onClick = {
                                    productSearchInput = ""
                                    isSearchDropdownOpen = false
                                }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_product_billing_input")
                    )

                    // Matching product results dropdown list
                    if (isSearchDropdownOpen && productSearchInput.isNotBlank()) {
                        val matching = allProducts.filter {
                            it.name.contains(productSearchInput, ignoreCase = true) ||
                            it.hindiName.contains(productSearchInput, ignoreCase = true) ||
                            it.barcode.contains(productSearchInput, ignoreCase = true)
                        }.take(5)

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                        ) {
                            if (matching.isEmpty()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "कोई उत्पाद नहीं मिला / No product found",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Button(
                                        onClick = {
                                            showAddProductDialog = true
                                            isSearchDropdownOpen = false
                                        },
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Text("+ नया बनाएँ / Add New", fontSize = 12.sp)
                                    }
                                }
                            } else {
                                matching.forEach { prod ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                viewModel.addProductToCart(prod)
                                                productSearchInput = ""
                                                isSearchDropdownOpen = false
                                            }
                                            .padding(vertical = 8.dp, horizontal = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = prod.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = "MRP: ₹${prod.mrp} • Offer: ₹${prod.sellingPrice} (Save ₹${prod.savingsPerUnit})",
                                                fontSize = 11.sp,
                                                color = Color(0xFF2E7D32)
                                            )
                                        }
                                        FilledTonalButton(
                                            onClick = {
                                                viewModel.addProductToCart(prod)
                                                productSearchInput = ""
                                                isSearchDropdownOpen = false
                                            },
                                            modifier = Modifier.height(34.dp)
                                        ) {
                                            Text("+ Add", fontSize = 11.sp)
                                        }
                                    }
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Customer Selection Card (Walk-in or Khata Customer)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (cart.selectedCustomer != null) cart.selectedCustomer!!.name else "Walk-in Customer / सामान्य ग्राहक",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        if (cart.selectedCustomer != null) {
                            Text(
                                text = "📱 ${cart.selectedCustomer!!.phone} • Udhar: ₹${"%.2f".format(cart.selectedCustomer!!.totalCreditDue)}",
                                fontSize = 11.sp,
                                color = if (cart.selectedCustomer!!.totalCreditDue > 0) Color(0xFFC62828) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Text(
                                text = "खाता या उधारी के लिए ग्राहक चुनें / Select customer for Khata",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (cart.selectedCustomer != null) {
                        IconButton(onClick = { viewModel.selectCustomer(null) }) {
                            Icon(Icons.Default.Clear, contentDescription = "Remove Customer")
                        }
                    } else {
                        Button(
                            onClick = { isCustomerSelectOpen = true },
                            modifier = Modifier
                                .height(38.dp)
                                .testTag("select_customer_btn")
                        ) {
                            Text("चुनें / Select", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Customer Selection Dialog
        if (isCustomerSelectOpen) {
            item {
                CustomerSelectDropdownCard(
                    customers = allCustomers,
                    onSelect = { cust ->
                        viewModel.selectCustomer(cust)
                        isCustomerSelectOpen = false
                    },
                    onAddNew = {
                        isCustomerSelectOpen = false
                        showAddCustomerDialog = true
                    },
                    onDismiss = { isCustomerSelectOpen = false }
                )
            }
        }

        // Cart Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "बिल आइटम / Cart Items (${cart.items.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (cart.items.isNotEmpty()) {
                    Text(
                        text = "खाली करें / Clear All",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { viewModel.clearCart() }
                    )
                }
            }
        }

        // Empty Cart Placeholder
        if (cart.items.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "कार्ट खाली है / Cart is Empty",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "कैमरा से बारकोड स्कैन करें या ऊपर नाम से उत्पाद जोड़ें।",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            // Cart Items
            items(cart.items, key = { it.product.id }) { item ->
                CartItemRow(
                    item = item,
                    onQuantityChange = { newQty ->
                        viewModel.updateCartItemQuantity(item.product.id, newQty)
                    },
                    onRemove = {
                        viewModel.removeCartItem(item.product.id)
                    }
                )
            }

            // Calculation Summary Card
            item {
                BillingSummaryCard(
                    cart = cart,
                    discountInput = discountInput,
                    onDiscountChange = { input ->
                        discountInput = input
                        val d = input.toDoubleOrNull() ?: 0.0
                        viewModel.setBillDiscount(d, cart.isPercentageDiscount)
                    },
                    onDiscountTypeToggle = { isPercent ->
                        val d = discountInput.toDoubleOrNull() ?: 0.0
                        viewModel.setBillDiscount(d, isPercent)
                    },
                    onPaymentModeChange = { mode ->
                        viewModel.setPaymentMode(mode)
                    },
                    amountPaidInput = amountPaidInput,
                    onAmountPaidChange = { input ->
                        amountPaidInput = input
                        val p = input.toDoubleOrNull() ?: 0.0
                        viewModel.setAmountPaid(p)
                    }
                )
            }

            // Action Buttons: Save & Print, Share PDF
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.checkout(
                                context = context,
                                onSuccess = { bill, file ->
                                    discountInput = ""
                                    amountPaidInput = ""
                                    onBillGenerated(bill, file)
                                },
                                onError = { err ->
                                    viewModel.showToast(err)
                                }
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("checkout_print_btn"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "बिल बनाएं और प्रिंट करें / Save & Print (₹${"%.2f".format(cart.finalPayable)})",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.checkout(
                                context = context,
                                onSuccess = { bill, file ->
                                    discountInput = ""
                                    amountPaidInput = ""
                                    PdfReceiptGenerator.sharePdfReceipt(context, file, bill.billNumber)
                                    onBillGenerated(bill, file)
                                },
                                onError = { err ->
                                    viewModel.showToast(err)
                                }
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("checkout_share_pdf_btn"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "पीडीएफ शेयर करें / Share Invoice PDF",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CartItemRow(
    item: CartItem,
    onQuantityChange: (Double) -> Unit,
    onRemove: () -> Unit
) {
    val isOutOfStockOrExceeded = item.quantity > item.product.currentStock
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = if (isOutOfStockOrExceeded) Color(0xFFFFF3E0) else MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Row 1: Title & Item Total
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.product.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    if (item.product.hindiName.isNotBlank()) {
                        Text(
                            text = item.product.hindiName,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    // Stock indicator
                    Text(
                        text = if (isOutOfStockOrExceeded) {
                            "⚠️ स्टॉक सीमा पार! उपलब्ध: ${item.product.currentStock.toInt()} ${item.product.unit}"
                        } else {
                            "उपलब्ध स्टॉक: ${item.product.currentStock.toInt()} ${item.product.unit}"
                        },
                        fontSize = 11.sp,
                        fontWeight = if (isOutOfStockOrExceeded) FontWeight.Bold else FontWeight.Normal,
                        color = if (isOutOfStockOrExceeded) MaterialTheme.colorScheme.error else Color(0xFF2E7D32),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "₹${"%.2f".format(item.itemTotal)}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (item.itemSavings > 0) {
                        Text(
                            text = "बचत: ₹${"%.2f".format(item.itemSavings)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF2E7D32)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row 2: MRP, Offer Price Badge & Quantity Stepper
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Pricing Tag
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (item.product.mrp > item.unitPrice) {
                        Text(
                            text = "₹${item.product.mrp}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                textDecoration = TextDecoration.LineThrough
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text(
                        text = "₹${item.unitPrice} / ${item.product.unit}",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }

                // Stepper: - [Qty] + and Delete
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { onQuantityChange((item.quantity - 1.0).coerceAtLeast(0.0)) },
                        modifier = Modifier
                            .size(34.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                    }

                    Text(
                        text = if (item.quantity % 1.0 == 0.0) item.quantity.toInt().toString() else "%.1f".format(item.quantity),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )

                    IconButton(
                        onClick = { onQuantityChange(item.quantity + 1.0) },
                        modifier = Modifier
                            .size(34.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp))
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = onRemove,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Remove",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BillingSummaryCard(
    cart: com.example.ui.CartState,
    discountInput: String,
    onDiscountChange: (String) -> Unit,
    onDiscountTypeToggle: (Boolean) -> Unit,
    onPaymentModeChange: (String) -> Unit,
    amountPaidInput: String,
    onAmountPaidChange: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "बिल विवरण / Bill Summary",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(10.dp))

            // MRP Subtotal
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "कुल एमआरपी / Total MRP:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "₹${"%.2f".format(cart.mrpTotal)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Selling Subtotal
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "बिक्री उप-योग / Subtotal:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "₹${"%.2f".format(cart.subtotal)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Extra Bill Discount with % and ₹ Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "अतिरिक्त छूट / Extra Discount:",
                        fontSize = 13.sp,
                        color = Color(0xFF2E7D32),
                        fontWeight = FontWeight.Medium
                    )
                    if (cart.isPercentageDiscount && cart.billDiscount > 0) {
                        Text(
                            text = "(₹${"%.2f".format(cart.billDiscount)} की छूट)",
                            fontSize = 11.sp,
                            color = Color(0xFF2E7D32)
                        )
                    }
                }

                // Currency / Percentage Toggle
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (!cart.isPercentageDiscount) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { onDiscountTypeToggle(false) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "₹",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (!cart.isPercentageDiscount) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (cart.isPercentageDiscount) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { onDiscountTypeToggle(true) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "%",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (cart.isPercentageDiscount) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                OutlinedTextField(
                    value = discountInput,
                    onValueChange = onDiscountChange,
                    placeholder = { Text(if (cart.isPercentageDiscount) "0 %" else "0.0") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .width(96.dp)
                        .height(48.dp)
                        .testTag("bill_discount_input")
                )
            }

            // Customer Savings Highlight Banner
            if (cart.totalSavings > 0.01) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE0B2)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🎉 ग्राहक की कुल बचत / Total Savings: ₹${"%.2f".format(cart.totalSavings)}",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE65100),
                            fontSize = 13.sp
                        )
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            // Final Payable Amount
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "कुल देय राशि / Final Payable",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${cart.items.size} वस्तुएँ • ${cart.totalQuantity} इकाई",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = "₹${"%.2f".format(cart.finalPayable)}",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Payment Mode Selector Chips
            Text(
                text = "भुगतान का प्रकार / Payment Mode:",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "CASH" to "नकद / Cash",
                    "UPI" to "यूपीआई / UPI",
                    "CREDIT_KHATA" to "उधार / Khata",
                    "PARTIAL" to "आंशिक / Partial"
                ).forEach { (mode, label) ->
                    FilterChip(
                        selected = cart.paymentMode == mode,
                        onClick = { onPaymentModeChange(mode) },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = if (mode == "CREDIT_KHATA") MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }

            // Amount Received / Cash Tender Field (supports cash change calculation or partial payment)
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = amountPaidInput,
                onValueChange = onAmountPaidChange,
                label = { Text("प्राप्त राशि / Amount Received (₹)") },
                placeholder = { Text("₹${"%.2f".format(cart.finalPayable)}") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("amount_paid_input")
            )

            // Change to Return Display (Green Card)
            if (cart.changeToReturn > 0.001) {
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "वापस करने के लिए नकद / Change to Return:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF1B5E20)
                        )
                        Text(
                            text = "₹${"%.2f".format(cart.changeToReturn)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = Color(0xFF1B5E20)
                        )
                    }
                }
            } else if (cart.balanceDue > 0.001 && (cart.paymentMode == "PARTIAL" || cart.paymentMode == "CREDIT_KHATA" || amountPaidInput.isNotBlank())) {
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "बाकी उधार / Balance Due (Udhar):",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFFC62828)
                        )
                        Text(
                            text = "₹${"%.2f".format(cart.balanceDue)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = Color(0xFFC62828)
                        )
                    }
                }
            } else if (cart.paymentMode == "CREDIT_KHATA") {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = Color(0xFFFFEBEE),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "पूरा बिल ₹${"%.2f".format(cart.finalPayable)} ग्राहक के उधार खाते (Khata) में दर्ज होगा।",
                        fontSize = 12.sp,
                        color = Color(0xFFC62828),
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CustomerSelectDropdownCard(
    customers: List<Customer>,
    onSelect: (Customer) -> Unit,
    onAddNew: () -> Unit,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ग्राहक चुनें / Select Customer",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Button(
                    onClick = onAddNew,
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("नया / New", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            customers.take(5).forEach { cust ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(cust) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(cust.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("📱 ${cust.phone}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (cust.totalCreditDue > 0) {
                        Text(
                            text = "Udhar: ₹${"%.2f".format(cust.totalCreditDue)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFC62828)
                        )
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            }

            Spacer(modifier = Modifier.height(6.dp))
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Close / बंद करें", fontSize = 12.sp)
            }
        }
    }
}
