package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.model.Bill
import com.example.data.model.BillItem
import com.example.data.model.Customer
import com.example.data.model.CustomerPayment
import com.example.data.model.Product
import com.example.util.MoneyUtil
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class BillingRepository(
    private val database: AppDatabase
) {
    private val productDao = database.productDao()
    private val customerDao = database.customerDao()
    private val billDao = database.billDao()
    private val paymentDao = database.customerPaymentDao()

    private val billingMutex = Mutex()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val billItemListType = Types.newParameterizedType(List::class.java, BillItem::class.java)
    private val billItemListAdapter = moshi.adapter<List<BillItem>>(billItemListType)

    // Products
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val lowStockProducts: Flow<List<Product>> = productDao.getLowStockProducts()

    fun searchProducts(query: String): Flow<List<Product>> = productDao.searchProducts(query)

    suspend fun getProductByBarcode(barcode: String): Product? = withContext(Dispatchers.IO) {
        productDao.getProductByBarcode(barcode.trim())
    }

    suspend fun getProductById(id: String): Product? = withContext(Dispatchers.IO) {
        productDao.getProductById(id)
    }

    suspend fun saveProduct(product: Product) = withContext(Dispatchers.IO) {
        val safe = product.copy(
            mrp = MoneyUtil.round(product.mrp.coerceAtLeast(0.0)),
            sellingPrice = MoneyUtil.round(product.sellingPrice.coerceAtLeast(0.0)),
            costPrice = MoneyUtil.round(product.costPrice.coerceAtLeast(0.0)),
            updatedAt = System.currentTimeMillis()
        )
        productDao.insert(safe)
    }

    suspend fun deleteProduct(product: Product) = withContext(Dispatchers.IO) {
        productDao.delete(product)
    }

    suspend fun updateStock(productId: String, newStock: Double) = withContext(Dispatchers.IO) {
        productDao.updateStock(productId, newStock.coerceAtLeast(0.0))
    }

    // Customers
    val allCustomers: Flow<List<Customer>> = customerDao.getAllCustomers()

    fun searchCustomers(query: String): Flow<List<Customer>> = customerDao.searchCustomers(query)

    suspend fun getCustomerById(id: String): Customer? = withContext(Dispatchers.IO) {
        customerDao.getCustomerById(id)
    }

    suspend fun saveCustomer(customer: Customer) = withContext(Dispatchers.IO) {
        val safe = customer.copy(
            totalCreditDue = MoneyUtil.round(customer.totalCreditDue.coerceAtLeast(0.0)),
            totalPurchases = MoneyUtil.round(customer.totalPurchases.coerceAtLeast(0.0)),
            updatedAt = System.currentTimeMillis()
        )
        customerDao.insert(safe)
    }

    suspend fun deleteCustomer(customer: Customer) = withContext(Dispatchers.IO) {
        customerDao.delete(customer)
    }

    /**
     * Record Khata / Udhar repayment atomically using Room database transaction.
     * Decreases the customer's outstanding balance safely without recording a new sale.
     */
    suspend fun recordCustomerPayment(
        customerId: String,
        amount: Double,
        paymentMode: String,
        notes: String
    ): Result<CustomerPayment> = withContext(Dispatchers.IO) {
        billingMutex.withLock {
            try {
                val safeAmount = MoneyUtil.round(amount.coerceAtLeast(0.0))
                if (safeAmount <= 0.0) {
                    return@withContext Result.failure(IllegalArgumentException("भुगतान राशि शून्य से अधिक होनी चाहिए / Payment amount must be greater than 0"))
                }

                database.withTransaction {
                    val customer = customerDao.getCustomerById(customerId)
                        ?: throw NoSuchElementException("ग्राहक नहीं मिला / Customer not found")

                    val payment = CustomerPayment(
                        customerId = customerId,
                        customerName = customer.name,
                        amount = safeAmount,
                        paymentMode = paymentMode,
                        timestamp = System.currentTimeMillis(),
                        notes = notes
                    )

                    paymentDao.insert(payment)
                    customerDao.adjustCreditDue(customerId, -safeAmount)

                    Result.success(payment)
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    fun getPaymentsForCustomer(customerId: String): Flow<List<CustomerPayment>> =
        paymentDao.getPaymentsForCustomer(customerId)

    val allPayments: Flow<List<CustomerPayment>> = paymentDao.getAllPayments()

    // Bills
    val allBills: Flow<List<Bill>> = billDao.getAllBills()
    val pendingCreditBills: Flow<List<Bill>> = billDao.getPendingCreditBills()

    fun searchBills(query: String): Flow<List<Bill>> = billDao.searchBills(query)

    suspend fun getBillById(id: String): Bill? = withContext(Dispatchers.IO) {
        billDao.getBillById(id)
    }

    /**
     * Generate sequential, automatic bill numbers (e.g. MMP-20261029-0001).
     */
    suspend fun generateNextBillNumber(): String = withContext(Dispatchers.IO) {
        val datePrefix = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
        val count = billDao.getTotalBillsCount() + 1
        "MMP-$datePrefix-${String.format(Locale.US, "%04d", count)}"
    }

    /**
     * Complete bill creation using an ATOMIC Room Transaction.
     * 1. Validates stock sufficiency (prevents overselling).
     * 2. Guards against duplicate bill processing.
     * 3. Inserts Bill record.
     * 4. Decrements inventory stock for all products.
     * 5. Updates customer purchases and Khata balance.
     * If ANY step fails, the entire transaction is rolled back cleanly.
     */
    suspend fun completeBilling(
        bill: Bill,
        items: List<BillItem>,
        allowOverselling: Boolean = false
    ): Result<Bill> = withContext(Dispatchers.IO) {
        billingMutex.withLock {
            try {
                if (items.isEmpty()) {
                    return@withContext Result.failure(IllegalArgumentException("कार्ट में कम से कम एक उत्पाद होना चाहिए / Cart cannot be empty"))
                }

                database.withTransaction {
                    // 1. Stock Validation
                    for (item in items) {
                        if (item.productId.isNotBlank()) {
                            val product = productDao.getProductById(item.productId)
                                ?: throw NoSuchElementException("उत्पाद '${item.productName}' डेटाबेस में नहीं मिला")

                            if (!allowOverselling && product.currentStock < item.quantity) {
                                throw IllegalStateException(
                                    "अपर्याप्त स्टॉक: '${product.name}' के केवल ${product.currentStock} ${product.unit} उपलब्ध हैं (आवश्यक: ${item.quantity})"
                                )
                            }
                        }
                    }

                    // 2. Prevent duplicate bill insertion
                    val existing = billDao.getBillByNumber(bill.billNumber)
                    if (existing != null) {
                        throw IllegalStateException("बिल संख्या '${bill.billNumber}' पहले से ही मौजूद है")
                    }

                    // 3. Encode items and insert Bill
                    val itemsJson = billItemListAdapter.toJson(items)
                    val safeBill = bill.copy(
                        mrpTotal = MoneyUtil.round(bill.mrpTotal),
                        subtotal = MoneyUtil.round(bill.subtotal),
                        discountAmount = MoneyUtil.round(bill.discountAmount),
                        finalAmount = MoneyUtil.round(bill.finalAmount),
                        productSavings = MoneyUtil.round(bill.productSavings),
                        totalSavings = MoneyUtil.round(bill.totalSavings),
                        amountPaid = MoneyUtil.round(bill.amountPaid),
                        balanceDue = MoneyUtil.round(bill.balanceDue),
                        itemsJson = itemsJson
                    )
                    billDao.insert(safeBill)

                    // 4. Atomic Stock Decrement
                    for (item in items) {
                        if (item.productId.isNotBlank()) {
                            productDao.decrementStock(item.productId, item.quantity)
                        }
                    }

                    // 5. Customer Purchases and Credit update
                    val customerId = safeBill.customerId
                    if (!customerId.isNullOrBlank()) {
                        customerDao.addPurchase(customerId, safeBill.finalAmount)
                        if (safeBill.balanceDue > 0.01) {
                            customerDao.adjustCreditDue(customerId, safeBill.balanceDue)
                        }
                    }

                    Result.success(safeBill)
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    fun decodeBillItems(json: String): List<BillItem> {
        return try {
            billItemListAdapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    // Cloud Sync with Firestore (Guarded against missing config & unauthenticated access)
    suspend fun syncWithFirestore(): Result<String> = withContext(Dispatchers.IO) {
        try {
            // Check if Firebase is initialized safely
            val isFirebaseReady = try {
                FirebaseApp.getInstance() != null
            } catch (e: Exception) {
                false
            }
            if (!isFirebaseReady) {
                return@withContext Result.failure(
                    IllegalStateException("Firebase कॉन्फ़िगरेशन (google-services.json) मौजूद नहीं है। आपका M Mart Pro ऐप स्थानीय Room Database में 100% ऑफ़लाइन काम कर रहा है।")
                )
            }

            val auth = FirebaseAuth.getInstance()
            val currentUser = auth.currentUser
            val ownerId = currentUser?.uid ?: "local_store"

            val firestore = FirebaseFirestore.getInstance()

            // 1. Sync Products under user's isolated store
            val products = productDao.getAllProductsSnapshot()
            for (p in products) {
                firestore.collection("stores").document(ownerId)
                    .collection("products").document(p.id)
                    .set(p.copy(ownerId = ownerId))
                    .await()
            }

            // 2. Sync Customers under user's isolated store
            val customers = customerDao.getAllCustomersSnapshot()
            for (c in customers) {
                firestore.collection("stores").document(ownerId)
                    .collection("customers").document(c.id)
                    .set(c.copy(ownerId = ownerId))
                    .await()
            }

            // 3. Sync Bills
            val bills = billDao.getAllBillsSnapshot()
            for (b in bills) {
                firestore.collection("stores").document(ownerId)
                    .collection("bills").document(b.id)
                    .set(b.copy(ownerId = ownerId))
                    .await()
            }

            // 4. Sync Payments
            val payments = paymentDao.getAllPaymentsSnapshot()
            for (pm in payments) {
                firestore.collection("stores").document(ownerId)
                    .collection("payments").document(pm.id)
                    .set(pm.copy(ownerId = ownerId))
                    .await()
            }

            Result.success("क्लाउड सिंक सफल: ${products.size} उत्पाद, ${customers.size} ग्राहक, ${bills.size} बिल सिंक हुए।")
        } catch (e: Exception) {
            Result.failure(
                Exception(e.localizedMessage ?: "क्लाउड सिंक विफल हुआ। कृपया इंटरनेट कनेक्शन जाँचें।")
            )
        }
    }

    // Backup & Restore
    suspend fun exportBackupJson(): String = withContext(Dispatchers.IO) {
        val products = productDao.getAllProductsSnapshot()
        val customers = customerDao.getAllCustomersSnapshot()
        val bills = billDao.getAllBillsSnapshot()
        val payments = paymentDao.getAllPaymentsSnapshot()

        val map = mapOf(
            "version" to 1,
            "appName" to "M Mart Pro",
            "exportedAt" to System.currentTimeMillis(),
            "products" to products,
            "customers" to customers,
            "bills" to bills,
            "payments" to payments
        )

        val adapter = moshi.adapter(Map::class.java)
        adapter.toJson(map)
    }

    suspend fun restoreBackupJson(jsonString: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val adapter = moshi.adapter(Map::class.java)
            val map = adapter.fromJson(jsonString) ?: return@withContext Result.failure(Exception("अमान्य बैकअप JSON / Invalid backup JSON format"))

            val productListAdapter = moshi.adapter<List<Product>>(Types.newParameterizedType(List::class.java, Product::class.java))
            val customerListAdapter = moshi.adapter<List<Customer>>(Types.newParameterizedType(List::class.java, Customer::class.java))
            val billListAdapter = moshi.adapter<List<Bill>>(Types.newParameterizedType(List::class.java, Bill::class.java))
            val paymentListAdapter = moshi.adapter<List<CustomerPayment>>(Types.newParameterizedType(List::class.java, CustomerPayment::class.java))

            database.withTransaction {
                val productsRaw = map["products"]
                if (productsRaw != null) {
                    val pJson = moshi.adapter(Any::class.java).toJson(productsRaw)
                    val pList = productListAdapter.fromJson(pJson)
                    if (pList != null) productDao.insertAll(pList)
                }

                val customersRaw = map["customers"]
                if (customersRaw != null) {
                    val cJson = moshi.adapter(Any::class.java).toJson(customersRaw)
                    val cList = customerListAdapter.fromJson(cJson)
                    if (cList != null) customerDao.insertAll(cList)
                }

                val billsRaw = map["bills"]
                if (billsRaw != null) {
                    val bJson = moshi.adapter(Any::class.java).toJson(billsRaw)
                    val bList = billListAdapter.fromJson(bJson)
                    if (bList != null) billDao.insertAll(bList)
                }

                val paymentsRaw = map["payments"]
                if (paymentsRaw != null) {
                    val pmJson = moshi.adapter(Any::class.java).toJson(paymentsRaw)
                    val pmList = paymentListAdapter.fromJson(pmJson)
                    if (pmList != null) paymentDao.insertAll(pmList)
                }
            }

            Result.success("डेटा सफलतापूर्वक रीस्टोर हो गया है।")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
