package com.example.util

import android.annotation.SuppressLint
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.atomic.AtomicBoolean

class BarcodeAnalyzer(
    private val onBarcodeScanned: (String) -> Unit
) : ImageAnalysis.Analyzer {

    // Configure ML Kit scanner to support retail formats: EAN-13, EAN-8, UPC-A, UPC-E, Code 128, Code 39, QR
    private val options = BarcodeScannerOptions.Builder()
        .setBarcodeFormats(
            Barcode.FORMAT_EAN_13,
            Barcode.FORMAT_EAN_8,
            Barcode.FORMAT_UPC_A,
            Barcode.FORMAT_UPC_E,
            Barcode.FORMAT_CODE_128,
            Barcode.FORMAT_CODE_39,
            Barcode.FORMAT_QR_CODE
        )
        .build()

    private val scanner = BarcodeScanning.getClient(options)

    private val isScanningEnabled = AtomicBoolean(true)
    private val isAnalyzing = AtomicBoolean(false)

    private var lastScannedBarcode: String? = null
    private var lastScannedTimestamp: Long = 0L

    // Minimum cooldown for the same barcode to prevent auto-repetitive additions while held in frame
    private val sameBarcodeCooldownMs = 3000L

    fun pauseScanning() {
        isScanningEnabled.set(false)
    }

    fun resumeScanning() {
        isScanningEnabled.set(true)
    }

    fun resetLastBarcode() {
        lastScannedBarcode = null
        lastScannedTimestamp = 0L
    }

    fun close() {
        try {
            scanner.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        if (!isScanningEnabled.get()) {
            imageProxy.close()
            return
        }

        // Prevent overlapping frame processing
        if (!isAnalyzing.compareAndSet(false, true)) {
            imageProxy.close()
            return
        }

        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

            scanner.process(image)
                .addOnSuccessListener { barcodes ->
                    val now = System.currentTimeMillis()
                    for (barcode in barcodes) {
                        val rawValue = barcode.rawValue?.trim()
                        if (!rawValue.isNullOrBlank()) {
                            // Duplicate check:
                            // If it's the exact same barcode, require a 3-second delay or removal from view
                            val isDuplicate = (rawValue == lastScannedBarcode) && (now - lastScannedTimestamp < sameBarcodeCooldownMs)

                            if (!isDuplicate) {
                                lastScannedBarcode = rawValue
                                lastScannedTimestamp = now
                                onBarcodeScanned(rawValue)
                            }
                            break
                        }
                    }
                }
                .addOnFailureListener {
                    // Ignore transient frame analysis failures
                }
                .addOnCompleteListener {
                    isAnalyzing.set(false)
                    imageProxy.close()
                }
        } else {
            isAnalyzing.set(false)
            imageProxy.close()
        }
    }
}
