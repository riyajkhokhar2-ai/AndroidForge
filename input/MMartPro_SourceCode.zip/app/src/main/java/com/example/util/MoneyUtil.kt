package com.example.util

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

object MoneyUtil {
    private val symbols = DecimalFormatSymbols(Locale.US)
    private val currencyFormat = DecimalFormat("0.00", symbols)

    /**
     * Safely rounds any Double to 2 decimal places using HALF_UP rounding.
     * Prevents floating-point precision errors (e.g. 0.1 + 0.2 = 0.30000000000000004).
     */
    fun round(value: Double): Double {
        if (value.isNaN() || value.isInfinite()) return 0.0
        return BigDecimal(value.toString())
            .setScale(2, RoundingMode.HALF_UP)
            .toDouble()
    }

    /**
     * Formats an amount as a standard 2-decimal currency string (e.g. "125.50").
     */
    fun format(amount: Double): String {
        return currencyFormat.format(round(amount))
    }

    /**
     * Calculates discount in Rupees based on type:
     * - If PERCENTAGE: (subtotal * percent / 100), capped between 0 and subtotal.
     * - If FIXED: clamped between 0 and subtotal.
     */
    fun calculateDiscount(subtotal: Double, discountValue: Double, isPercentage: Boolean): Double {
        val safeSubtotal = round(subtotal.coerceAtLeast(0.0))
        val safeDiscount = discountValue.coerceAtLeast(0.0)

        val discountInRupees = if (isPercentage) {
            val validPercent = safeDiscount.coerceIn(0.0, 100.0)
            BigDecimal(safeSubtotal.toString())
                .multiply(BigDecimal(validPercent.toString()))
                .divide(BigDecimal("100"), 2, RoundingMode.HALF_UP)
                .toDouble()
        } else {
            round(safeDiscount)
        }

        return discountInRupees.coerceIn(0.0, safeSubtotal)
    }

    /**
     * Safely calculates item total: round(quantity * unitPrice).
     */
    fun calculateItemTotal(quantity: Double, unitPrice: Double): Double {
        val safeQty = quantity.coerceAtLeast(0.0)
        val safePrice = unitPrice.coerceAtLeast(0.0)
        return BigDecimal(safeQty.toString())
            .multiply(BigDecimal(safePrice.toString()))
            .setScale(2, RoundingMode.HALF_UP)
            .toDouble()
    }
}
