package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette - Professional Teal & Crisp Grey
val TealPrimary = Color(0xFF00796B)
val TealOnPrimary = Color(0xFFFFFFFF)
val TealPrimaryContainer = Color(0xFFD8F3ED)
val TealOnPrimaryContainer = Color(0xFF00201C)

val TealSecondary = Color(0xFF00897B)
val TealOnSecondary = Color(0xFFFFFFFF)
val TealSecondaryContainer = Color(0xFFCEEBE6)
val TealOnSecondaryContainer = Color(0xFF00201C)

val AccentSavings = Color(0xFFE65100) // Deep Orange for Savings & Highlights
val AccentSavingsContainer = Color(0xFFFFE0B2)
val OnAccentSavings = Color(0xFFFFFFFF)

val SuccessGreen = Color(0xFF2E7D32)
val SuccessGreenContainer = Color(0xFFE8F5E9)

val CreditRed = Color(0xFFC62828) // For Outstanding Udhar / Credit
val CreditRedContainer = Color(0xFFFFEBEE)

val LightBackground = Color(0xFFF7F9FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF3F3)
val LightOnSurface = Color(0xFF191C1C)
val LightOnSurfaceVariant = Color(0xFF3F4948)
val LightOutline = Color(0xFFD0D7D7)

// Dark Palette
val TealPrimaryDark = Color(0xFF4DB6AC)
val TealOnPrimaryDark = Color(0xFF003730)
val TealPrimaryContainerDark = Color(0xFF005047)
val TealOnPrimaryContainerDark = Color(0xFF80CBC4)

val DarkBackground = Color(0xFF121515)
val DarkSurface = Color(0xFF1B2020)
val DarkSurfaceVariant = Color(0xFF262F2E)
val DarkOnSurface = Color(0xFFE1E3E3)
val DarkOnSurfaceVariant = Color(0xFFBFC9C7)
val DarkOutline = Color(0xFF4B5554)
