package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.Bill
import com.example.data.model.Customer
import com.example.data.model.CustomerPayment
import com.example.data.model.Product
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Product::class,
        Customer::class,
        Bill::class,
        CustomerPayment::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun customerDao(): CustomerDao
    abstract fun billDao(): BillDao
    abstract fun customerPaymentDao(): CustomerPaymentDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mmart_pro.db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database)
                    }
                }
            }

            private suspend fun populateInitialData(database: AppDatabase) {
                val productDao = database.productDao()
                val customerDao = database.customerDao()

                // Seed popular retail products with barcodes & MRP / Offer Price
                val sampleProducts = listOf(
                    Product(
                        name = "Aashirvaad Shudh Chakki Atta 5kg",
                        hindiName = "आशीर्वाद शुद्ध चक्की आटा 5 किग्रा",
                        barcode = "8901030383822",
                        category = "Grocery / किराना",
                        unit = "Pkt",
                        mrp = 280.0,
                        sellingPrice = 245.0,
                        costPrice = 220.0,
                        currentStock = 35.0,
                        minStockAlert = 5.0
                    ),
                    Product(
                        name = "Fortune Sunlite Refined Oil 1L",
                        hindiName = "फॉर्च्यून रिफाइंड तेल 1 ली",
                        barcode = "8906007280014",
                        category = "Grocery / किराना",
                        unit = "Pkt",
                        mrp = 155.0,
                        sellingPrice = 138.0,
                        costPrice = 125.0,
                        currentStock = 42.0,
                        minStockAlert = 6.0
                    ),
                    Product(
                        name = "Tata Salt Iodized 1kg",
                        hindiName = "टाटा नमक आयोडीन युक्त 1 किग्रा",
                        barcode = "8901058000416",
                        category = "Grocery / किराना",
                        unit = "Pkt",
                        mrp = 28.0,
                        sellingPrice = 25.0,
                        costPrice = 21.0,
                        currentStock = 80.0,
                        minStockAlert = 10.0
                    ),
                    Product(
                        name = "Maggi 2-Minute Noodles 70g",
                        hindiName = "मैगी 2-मिनट नूडल्स 70 ग्रा",
                        barcode = "8901058852879",
                        category = "Snacks / स्नैक्स",
                        unit = "Pcs",
                        mrp = 14.0,
                        sellingPrice = 12.0,
                        costPrice = 10.0,
                        currentStock = 120.0,
                        minStockAlert = 15.0
                    ),
                    Product(
                        name = "Amul Butter Pasteurised 100g",
                        hindiName = "अमूल बटर मक्खन 100 ग्रा",
                        barcode = "8901262010058",
                        category = "Dairy / डेयरी",
                        unit = "Pcs",
                        mrp = 60.0,
                        sellingPrice = 56.0,
                        costPrice = 50.0,
                        currentStock = 25.0,
                        minStockAlert = 4.0
                    ),
                    Product(
                        name = "Cadbury Dairy Milk Silk 60g",
                        hindiName = "कैडबरी डेयरी मिल्क सिल्क",
                        barcode = "7622201438722",
                        category = "Chocolates / चॉकलेट",
                        unit = "Pcs",
                        mrp = 90.0,
                        sellingPrice = 82.0,
                        costPrice = 72.0,
                        currentStock = 40.0,
                        minStockAlert = 5.0
                    ),
                    Product(
                        name = "Colgate MaxFresh Toothpaste 150g",
                        hindiName = "कोलगेट मैक्सफ्रेश टूथपेस्ट",
                        barcode = "8901314010524",
                        category = "Personal Care / पर्सनल केयर",
                        unit = "Pcs",
                        mrp = 125.0,
                        sellingPrice = 105.0,
                        costPrice = 90.0,
                        currentStock = 30.0,
                        minStockAlert = 5.0
                    ),
                    Product(
                        name = "Surf Excel Easy Wash Detergent 1kg",
                        hindiName = "सर्फ एक्सेल इजी वॉश 1 किग्रा",
                        barcode = "8901030704207",
                        category = "Household / घरेलू",
                        unit = "Pkt",
                        mrp = 145.0,
                        sellingPrice = 129.0,
                        costPrice = 112.0,
                        currentStock = 28.0,
                        minStockAlert = 4.0
                    ),
                    Product(
                        name = "Britannia Good Day Butter Biscuits 120g",
                        hindiName = "ब्रिटानिया गुड डे बटर बिस्कुट",
                        barcode = "8901063012756",
                        category = "Snacks / स्नैक्स",
                        unit = "Pkt",
                        mrp = 30.0,
                        sellingPrice = 25.0,
                        costPrice = 21.0,
                        currentStock = 65.0,
                        minStockAlert = 8.0
                    ),
                    Product(
                        name = "Dettol Antiseptic Liquid 250ml",
                        hindiName = "डेटॉल एंटीसेप्टिक लिक्विड 250 मिली",
                        barcode = "8901396112109",
                        category = "Health / स्वास्थ्य",
                        unit = "Pcs",
                        mrp = 168.0,
                        sellingPrice = 152.0,
                        costPrice = 135.0,
                        currentStock = 18.0,
                        minStockAlert = 3.0
                    )
                )
                productDao.insertAll(sampleProducts)

                // Sample customers
                val sampleCustomers = listOf(
                    Customer(
                        name = "Rahul Sharma",
                        phone = "9876543210",
                        address = "Near Hanuman Mandir, Ward 4",
                        totalCreditDue = 450.0,
                        totalPurchases = 3200.0
                    ),
                    Customer(
                        name = "Amit Patel",
                        phone = "9823456789",
                        address = "Shop No. 5, Station Road",
                        totalCreditDue = 0.0,
                        totalPurchases = 5400.0
                    ),
                    Customer(
                        name = "Suresh Gupta",
                        phone = "9811223344",
                        address = "House 42, Gandhi Nagar",
                        totalCreditDue = 820.0,
                        totalPurchases = 4100.0
                    )
                )
                customerDao.insertAll(sampleCustomers)
            }
        }
    }
}
