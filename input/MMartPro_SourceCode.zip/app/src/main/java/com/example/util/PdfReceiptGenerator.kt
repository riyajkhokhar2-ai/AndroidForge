package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.model.Bill
import com.example.data.model.BillItem
import com.example.data.model.ShopSettings
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfReceiptGenerator {

    fun generateReceiptPdf(
        context: Context,
        bill: Bill,
        items: List<BillItem>,
        settings: ShopSettings
    ): File {
        val receiptsDir = File(context.cacheDir, "receipts")
        if (!receiptsDir.exists()) receiptsDir.mkdirs()

        val safeBillNum = bill.billNumber.replace("[^a-zA-Z0-9_-]".toRegex(), "_")
        val pdfFile = File(receiptsDir, "Bill_${safeBillNum}.pdf")

        val pageWidth = 420
        // Calculate dynamic height based on item count to ensure long bills are never clipped
        val baseHeight = 580
        val itemHeight = items.size * 36
        val qrHeight = if (settings.upiId.isNotBlank()) 120 else 20
        val pageHeight = (baseHeight + itemHeight + qrHeight).coerceAtLeast(600)

        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        // Background
        canvas.drawColor(Color.WHITE)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        var y = 30f

        // Header - Teal Branding Accent Bar
        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(0, 121, 107) // Teal
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 8f, accentPaint)

        // Store Name
        paint.color = Color.rgb(0, 77, 64) // Deep Teal
        paint.textSize = 20f
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(settings.shopName, (pageWidth / 2).toFloat(), y, paint)
        y += 18f

        // Tagline
        paint.color = Color.DKGRAY
        paint.textSize = 10f
        paint.isFakeBoldText = false
        if (settings.tagline.isNotBlank()) {
            canvas.drawText(settings.tagline, (pageWidth / 2).toFloat(), y, paint)
            y += 14f
        }

        // Address & Phone
        paint.textSize = 9f
        if (settings.address.isNotBlank()) {
            canvas.drawText(settings.address, (pageWidth / 2).toFloat(), y, paint)
            y += 13f
        }
        if (settings.phone.isNotBlank()) {
            canvas.drawText("Phone: ${settings.phone}", (pageWidth / 2).toFloat(), y, paint)
            y += 13f
        }
        if (settings.gstin.isNotBlank()) {
            canvas.drawText("GSTIN: ${settings.gstin}", (pageWidth / 2).toFloat(), y, paint)
            y += 14f
        }

        // Divider
        y += 4f
        drawDashedLine(canvas, 16f, y, (pageWidth - 16).toFloat(), y)
        y += 14f

        // Bill details
        paint.textAlign = Paint.Align.LEFT
        paint.textSize = 9.5f
        paint.color = Color.BLACK
        paint.isFakeBoldText = true

        val dateStr = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date(bill.timestamp))
        canvas.drawText("Bill No: ${bill.billNumber}", 16f, y, paint)
        paint.isFakeBoldText = false
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText("Date: $dateStr", (pageWidth - 16).toFloat(), y, paint)
        y += 14f

        paint.textAlign = Paint.Align.LEFT
        val custText = if (bill.customerName.isNotBlank()) {
            if (bill.customerPhone.isNotBlank()) "${bill.customerName} (${bill.customerPhone})" else bill.customerName
        } else {
            "Walk-in Customer"
        }
        canvas.drawText("Customer: $custText", 16f, y, paint)
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText("Pay Mode: ${bill.paymentMode}", (pageWidth - 16).toFloat(), y, paint)
        y += 14f

        // Divider
        drawDashedLine(canvas, 16f, y, (pageWidth - 16).toFloat(), y)
        y += 14f

        // Table Header
        paint.isFakeBoldText = true
        paint.textSize = 9.5f
        paint.color = Color.rgb(0, 121, 107)

        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("Item", 16f, y, paint)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("Qty", 230f, y, paint)
        canvas.drawText("Rate", 300f, y, paint)
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText("Amount", (pageWidth - 16).toFloat(), y, paint)
        y += 12f

        drawLine(canvas, 16f, y, (pageWidth - 16).toFloat(), y, Color.LTGRAY)
        y += 12f

        // Items
        paint.color = Color.BLACK
        for ((idx, item) in items.withIndex()) {
            paint.isFakeBoldText = true
            paint.textSize = 9f
            paint.textAlign = Paint.Align.LEFT

            // Truncate name if too long
            val nameDisplay = if (item.productName.length > 28) item.productName.take(26) + ".." else item.productName
            canvas.drawText("${idx + 1}. $nameDisplay", 16f, y, paint)

            paint.isFakeBoldText = false
            paint.textAlign = Paint.Align.CENTER
            val qtyStr = if (item.quantity % 1.0 == 0.0) item.quantity.toInt().toString() else "%.2f".format(item.quantity)
            canvas.drawText("$qtyStr ${item.unit}", 230f, y, paint)
            canvas.drawText("₹%.2f".format(item.unitPrice), 300f, y, paint)

            paint.textAlign = Paint.Align.RIGHT
            paint.isFakeBoldText = true
            canvas.drawText("₹%.2f".format(item.totalAmount), (pageWidth - 16).toFloat(), y, paint)
            y += 11f

            // Savings subtext if offer price < MRP
            if (item.savings > 0.01) {
                paint.isFakeBoldText = false
                paint.textSize = 8f
                paint.color = Color.rgb(198, 40, 40) // Subdued red/orange for MRP & savings
                paint.textAlign = Paint.Align.LEFT
                canvas.drawText("   (MRP: ₹%.2f | You Saved: ₹%.2f)".format(item.mrp, item.savings), 16f, y, paint)
                paint.color = Color.BLACK
                y += 10f
            } else {
                y += 3f
            }
        }

        // Table Bottom Divider
        y += 4f
        drawLine(canvas, 16f, y, (pageWidth - 16).toFloat(), y, Color.LTGRAY)
        y += 14f

        // Billing Summary
        paint.textSize = 9.5f
        paint.isFakeBoldText = false
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("MRP Subtotal:", 180f, y, paint)
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText("₹%.2f".format(bill.mrpTotal), (pageWidth - 16).toFloat(), y, paint)
        y += 13f

        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("Selling Price Subtotal:", 180f, y, paint)
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText("₹%.2f".format(bill.subtotal), (pageWidth - 16).toFloat(), y, paint)
        y += 13f

        if (bill.discountAmount > 0.01) {
            paint.textAlign = Paint.Align.LEFT
            paint.color = Color.rgb(46, 125, 50)
            canvas.drawText("Bill Discount (-):", 180f, y, paint)
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText("₹%.2f".format(bill.discountAmount), (pageWidth - 16).toFloat(), y, paint)
            paint.color = Color.BLACK
            y += 13f
        }

        // Final Payable Amount
        y += 4f
        val summaryBoxPaint = Paint().apply {
            color = Color.rgb(224, 242, 241) // Teal light container
            style = Paint.Style.FILL
        }
        canvas.drawRect(16f, y, (pageWidth - 16).toFloat(), y + 30f, summaryBoxPaint)

        paint.textSize = 13f
        paint.isFakeBoldText = true
        paint.color = Color.rgb(0, 77, 64)
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("GRAND TOTAL / कुल देय:", 26f, y + 20f, paint)
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText("₹%.2f".format(bill.finalAmount), (pageWidth - 26).toFloat(), y + 20f, paint)
        y += 40f

        // Customer Savings Banner
        if (bill.totalSavings > 0.01) {
            val savingsBoxPaint = Paint().apply {
                color = Color.rgb(255, 243, 224) // Orange tint
                style = Paint.Style.FILL
            }
            canvas.drawRect(16f, y, (pageWidth - 16).toFloat(), y + 22f, savingsBoxPaint)

            paint.textSize = 9.5f
            paint.isFakeBoldText = true
            paint.color = Color.rgb(230, 81, 0)
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("★ You Saved / आपकी कुल बचत: ₹%.2f ★".format(bill.totalSavings), (pageWidth / 2).toFloat(), y + 15f, paint)
            y += 30f
        }

        // Payment status
        paint.isFakeBoldText = false
        paint.textSize = 9.5f
        paint.color = Color.BLACK
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("Amount Paid: ₹%.2f".format(bill.amountPaid), 16f, y, paint)
        paint.textAlign = Paint.Align.RIGHT
        if (bill.balanceDue > 0.01) {
            paint.color = Color.rgb(198, 40, 40)
            paint.isFakeBoldText = true
            canvas.drawText("Balance Due (Udhar): ₹%.2f".format(bill.balanceDue), (pageWidth - 16).toFloat(), y, paint)
        } else {
            paint.color = Color.rgb(46, 125, 50)
            canvas.drawText("Status: FULLY PAID", (pageWidth - 16).toFloat(), y, paint)
        }
        y += 18f

        // UPI QR Code
        if (settings.upiId.isNotBlank()) {
            val upiPayload = "upi://pay?pa=${settings.upiId}&pn=${settings.shopName.replace(" ", "%20")}&am=${bill.finalAmount}&cu=INR"
            val qrBitmap = QrCodeGenerator.generateQrBitmap(upiPayload, 90)
            if (qrBitmap != null) {
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = 8.5f
                paint.color = Color.DKGRAY
                canvas.drawText("Scan & Pay via any UPI App (GPay, PhonePe, Paytm):", (pageWidth / 2).toFloat(), y, paint)
                y += 8f
                val qrX = ((pageWidth - 90) / 2).toFloat()
                canvas.drawBitmap(qrBitmap, qrX, y, null)
                y += 98f
            }
        }

        // Footer
        drawDashedLine(canvas, 16f, y, (pageWidth - 16).toFloat(), y)
        y += 14f

        paint.color = Color.DKGRAY
        paint.textSize = 9f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(settings.receiptFooter, (pageWidth / 2).toFloat(), y, paint)
        y += 12f
        paint.textSize = 8f
        canvas.drawText("Generated by M Mart Pro Smart Billing", (pageWidth / 2).toFloat(), y, paint)

        document.finishPage(page)

        FileOutputStream(pdfFile).use { out ->
            document.writeTo(out)
        }
        document.close()

        return pdfFile
    }

    private fun drawLine(canvas: Canvas, startX: Float, startY: Float, endX: Float, endY: Float, color: Int) {
        val paint = Paint().apply {
            this.color = color
            strokeWidth = 1f
        }
        canvas.drawLine(startX, startY, endX, endY, paint)
    }

    private fun drawDashedLine(canvas: Canvas, startX: Float, startY: Float, endX: Float, endY: Float) {
        val paint = Paint().apply {
            color = Color.GRAY
            strokeWidth = 1f
        }
        var currentX = startX
        val dash = 4f
        val gap = 3f
        while (currentX < endX) {
            canvas.drawLine(currentX, startY, (currentX + dash).coerceAtMost(endX), endY, paint)
            currentX += dash + gap
        }
    }

    fun sharePdfReceipt(context: Context, pdfFile: File, billNumber: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            pdfFile
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Receipt for Bill #$billNumber - M Mart Pro")
            putExtra(Intent.EXTRA_TEXT, "Here is your invoice for bill #$billNumber from M Mart Pro. Thank you for shopping with us!")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val chooser = Intent.createChooser(intent, "Share Bill Receipt / रसीद भेजें")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}
