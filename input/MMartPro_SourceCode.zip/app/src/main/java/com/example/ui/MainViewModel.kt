package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.Bill
import com.example.data.model.BillItem
import com.example.data.model.CartItem
import com.example.data.model.Customer
import com.example.data.model.CustomerPayment
import com.example.data.model.Product
import com.example.data.model.ShopSettings
import com.example.data.repository.BillingRepository
import com.example.util.BillPrintHelper
import com.example.util.MoneyUtil
import com.example.util.PdfReceiptGenerator
import com.example.util.ShopSettingsManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

sealed class Screen(val route: String, val titleEn: String, val titleHi: String) {
    object Dashboard : Screen("dashboard", "Dashboard", "डैशबोर्ड")
    object Billing : Screen("billing", "Billing", "बिलिंग")
    object Products : Screen("products", "Products", "उत्पाद")
    object Customers : Screen("customers", "Khata Book", "उधार खाता")
    object History : Screen("history", "Bill History", "बिल इतिहास")
    object Inventory : Screen("inventory", "Inventory", "स्टॉक")
    object Settings : Screen("settings", "Settings", "सेटिंग्स")
}

data class CartState(
    val items: List<CartItem> = emptyList(),
    val selectedCustomer: Customer? = null,
    val discountInput: Double = 0.0,
    val isDiscountPercent: Boolean = false,
    val paymentMode: String = "CASH", // CASH, UPI, CARD, CREDIT_KHATA, PARTIAL
    val amountPaid: Double = 0.0,
    val isAutoCalculatedPaid: Boolean = true,
    val notes: String = ""
) {
    val mrpTotal: Double get() = MoneyUtil.round(items.sumOf { it.mrpTotal })
    val subtotal: Double get() = MoneyUtil.round(items.sumOf { it.itemTotal })
    val productSavings: Double get() = MoneyUtil.round(items.sumOf { it.itemSavings })
    val discountAmount: Double get() = MoneyUtil.calculateDiscount(subtotal, discountInput, isDiscountPercent)
    val billDiscount: Double get() = discountAmount
    val isPercentageDiscount: Boolean get() = isDiscountPercent
    val finalPayable: Double get() = MoneyUtil.round((subtotal - discountAmount).coerceAtLeast(0.0))
    val totalSavings: Double get() = MoneyUtil.round(productSavings + discountAmount)
    val effectiveAmountPaid: Double get() = if (isAutoCalculatedPaid && paymentMode != "CREDIT_KHATA" && paymentMode != "PARTIAL") finalPayable else MoneyUtil.round(amountPaid)
    val balanceDue: Double get() = if (paymentMode == "CREDIT_KHATA") finalPayable else MoneyUtil.round((finalPayable - effectiveAmountPaid).coerceAtLeast(0.0))
    val changeToReturn: Double get() = if (effectiveAmountPaid > finalPayable) MoneyUtil.round(effectiveAmountPaid - finalPayable) else 0.0
    val totalQuantity: Double get() = items.sumOf { it.safeQuantity }
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    val repository = BillingRepository(database)
    val settingsManager = ShopSettingsManager(application)

    val settings: StateFlow<ShopSettings> = settingsManager.settings

    // Navigation
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Dashboard)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    // Products
    private val _productSearchQuery = MutableStateFlow("")
    val productSearchQuery: StateFlow<String> = _productSearchQuery.asStateFlow()

    fun setProductSearchQuery(query: String) {
        _productSearchQuery.value = query
    }

    val products: StateFlow<List<Product>> = _productSearchQuery
        .combine(repository.allProducts) { query, all ->
            if (query.isBlank()) all else all.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.hindiName.contains(query, ignoreCase = true) ||
                it.barcode.contains(query, ignoreCase = true) ||
                it.category.contains(query, ignoreCase = true)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockProducts: StateFlow<List<Product>> = repository.lowStockProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Customers
    private val _customerSearchQuery = MutableStateFlow("")
    val customerSearchQuery: StateFlow<String> = _customerSearchQuery.asStateFlow()

    fun setCustomerSearchQuery(query: String) {
        _customerSearchQuery.value = query
    }

    val customers: StateFlow<List<Customer>> = _customerSearchQuery
        .combine(repository.allCustomers) { query, all ->
            if (query.isBlank()) all else all.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.phone.contains(query, ignoreCase = true)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Bills
    private val _billSearchQuery = MutableStateFlow("")
    val billSearchQuery: StateFlow<String> = _billSearchQuery.asStateFlow()

    fun setBillSearchQuery(query: String) {
        _billSearchQuery.value = query
    }

    val bills: StateFlow<List<Bill>> = _billSearchQuery
        .combine(repository.allBills) { query, all ->
            if (query.isBlank()) all else all.filter {
                it.billNumber.contains(query, ignoreCase = true) ||
                it.customerName.contains(query, ignoreCase = true) ||
                it.customerPhone.contains(query, ignoreCase = true)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingCreditBills: StateFlow<List<Bill>> = repository.pendingCreditBills
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Cart & Billing State
    private val _cartState = MutableStateFlow(CartState())
    val cartState: StateFlow<CartState> = _cartState.asStateFlow()

    // Status message toast/banner
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Checkout in-progress flag to prevent duplicate submissions
    private var isCheckingOut = false

    fun clearToast() {
        _toastMessage.value = null
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    // Scanned barcode pending product creation
    private val _pendingBarcodeForAdd = MutableStateFlow<String?>(null)
    val pendingBarcodeForAdd: StateFlow<String?> = _pendingBarcodeForAdd.asStateFlow()

    fun clearPendingBarcode() {
        _pendingBarcodeForAdd.value = null
    }

    fun onBarcodeScanned(barcode: String, onProductNotFound: (String) -> Unit) {
        viewModelScope.launch {
            val product = repository.getProductByBarcode(barcode)
            if (product != null) {
                if (product.currentStock <= 0.0) {
                    showToast("चेतावनी: '${product.name}' का स्टॉक खत्म (0) है!")
                }
                addProductToCart(product)
                showToast("✓ जोड़ा गया: ${product.name} (स्टॉक: ${product.currentStock} ${product.unit})")
            } else {
                _pendingBarcodeForAdd.value = barcode
                showToast("उत्पाद नहीं मिला: $barcode. नया उत्पाद जोड़ें?")
                onProductNotFound(barcode)
            }
        }
    }

    fun addProductToCart(product: Product, quantity: Double = 1.0) {
        val safeQty = quantity.coerceAtLeast(0.01)
        val currentItems = _cartState.value.items.toMutableList()
        val existingIndex = currentItems.indexOfFirst { it.product.id == product.id }
        if (existingIndex >= 0) {
            val existing = currentItems[existingIndex]
            currentItems[existingIndex] = existing.copy(quantity = existing.quantity + safeQty)
        } else {
            currentItems.add(CartItem(product = product, quantity = safeQty))
        }
        updateCartItems(currentItems)
    }

    fun removeCartItem(productId: String) {
        val updated = _cartState.value.items.filterNot { it.product.id == productId }
        updateCartItems(updated)
    }

    fun updateCartItemQuantity(productId: String, newQty: Double) {
        if (newQty <= 0) {
            removeCartItem(productId)
            return
        }
        val safeQty = MoneyUtil.round(newQty.coerceAtLeast(0.01))
        val updated = _cartState.value.items.map {
            if (it.product.id == productId) it.copy(quantity = safeQty) else it
        }
        updateCartItems(updated)
    }

    fun updateCartItemPrice(productId: String, customPrice: Double) {
        val safePrice = MoneyUtil.round(customPrice.coerceAtLeast(0.0))
        val updated = _cartState.value.items.map {
            if (it.product.id == productId) it.copy(customPrice = safePrice) else it
        }
        updateCartItems(updated)
    }

    private fun updateCartItems(items: List<CartItem>) {
        val current = _cartState.value
        val updatedState = current.copy(items = items)
        _cartState.value = if (current.isAutoCalculatedPaid && current.paymentMode != "CREDIT_KHATA" && current.paymentMode != "PARTIAL") {
            updatedState.copy(amountPaid = updatedState.finalPayable)
        } else {
            updatedState
        }
    }

    fun selectCustomer(customer: Customer?) {
        _cartState.value = _cartState.value.copy(selectedCustomer = customer)
    }

    fun setBillDiscount(discount: Double, isPercent: Boolean = false) {
        val validDiscount = discount.coerceAtLeast(0.0)
        val current = _cartState.value
        val newState = current.copy(discountInput = validDiscount, isDiscountPercent = isPercent)
        _cartState.value = if (current.isAutoCalculatedPaid && current.paymentMode != "CREDIT_KHATA" && current.paymentMode != "PARTIAL") {
            newState.copy(amountPaid = newState.finalPayable)
        } else {
            newState
        }
    }

    fun setPaymentMode(mode: String) {
        val current = _cartState.value
        when (mode) {
            "CREDIT_KHATA" -> {
                _cartState.value = current.copy(paymentMode = mode, amountPaid = 0.0, isAutoCalculatedPaid = false)
            }
            "PARTIAL" -> {
                _cartState.value = current.copy(paymentMode = mode, isAutoCalculatedPaid = false)
            }
            else -> {
                _cartState.value = current.copy(
                    paymentMode = mode,
                    amountPaid = current.finalPayable,
                    isAutoCalculatedPaid = true
                )
            }
        }
    }

    fun setAmountPaid(amount: Double) {
        val safeAmount = MoneyUtil.round(amount.coerceAtLeast(0.0))
        _cartState.value = _cartState.value.copy(
            amountPaid = safeAmount,
            isAutoCalculatedPaid = false
        )
    }

    fun setNotes(notes: String) {
        _cartState.value = _cartState.value.copy(notes = notes)
    }

    fun clearCart() {
        _cartState.value = CartState()
    }

    fun checkout(
        context: Context,
        allowOverselling: Boolean = false,
        onSuccess: (Bill, File) -> Unit,
        onError: (String) -> Unit
    ) {
        if (isCheckingOut) {
            onError("बिल पहले से प्रोसेस हो रहा है... कृपया प्रतीक्षा करें")
            return
        }

        val cart = _cartState.value
        if (cart.items.isEmpty()) {
            onError("कार्ट खाली है / Cart is empty! कृपया उत्पाद जोड़ें।")
            return
        }

        // Validate items
        for (item in cart.items) {
            if (item.quantity <= 0.0) {
                onError("उत्पाद '${item.product.name}' की मात्रा अमान्य है")
                return
            }
            if (item.unitPrice < 0.0) {
                onError("उत्पाद '${item.product.name}' की कीमत अमान्य है")
                return
            }
        }

        isCheckingOut = true

        viewModelScope.launch {
            try {
                val billNumber = repository.generateNextBillNumber()
                val billItems = cart.items.map { item ->
                    BillItem(
                        productId = item.product.id,
                        productName = item.product.name,
                        hindiName = item.product.hindiName,
                        barcode = item.product.barcode,
                        unit = item.product.unit,
                        mrp = item.product.safeMrp,
                        unitPrice = item.unitPrice,
                        quantity = item.safeQuantity,
                        totalAmount = item.itemTotal,
                        savings = item.itemSavings
                    )
                }

                val finalPaid = cart.effectiveAmountPaid
                val balanceDue = cart.balanceDue

                val bill = Bill(
                    billNumber = billNumber,
                    customerId = cart.selectedCustomer?.id,
                    customerName = cart.selectedCustomer?.name ?: "Walk-in Customer",
                    customerPhone = cart.selectedCustomer?.phone ?: "",
                    mrpTotal = cart.mrpTotal,
                    subtotal = cart.subtotal,
                    discountAmount = cart.discountAmount,
                    finalAmount = cart.finalPayable,
                    productSavings = cart.productSavings,
                    totalSavings = cart.totalSavings,
                    amountPaid = finalPaid,
                    balanceDue = balanceDue,
                    paymentMode = cart.paymentMode,
                    notes = cart.notes
                )

                val result = repository.completeBilling(bill, billItems, allowOverselling)
                result.onSuccess { savedBill ->
                    // Generate PDF receipt safely
                    val pdfFile = PdfReceiptGenerator.generateReceiptPdf(
                        context = context,
                        bill = savedBill,
                        items = billItems,
                        settings = settings.value
                    )

                    // Auto-print if enabled in settings
                    if (settings.value.autoPrint) {
                        BillPrintHelper.printPdf(context, pdfFile, "Bill_${savedBill.billNumber}")
                    }

                    // Reset cart
                    clearCart()
                    showToast("✓ बिल ${savedBill.billNumber} सफलता से सुरक्षित हुआ!")
                    onSuccess(savedBill, pdfFile)
                }.onFailure { err ->
                    onError(err.message ?: "बिल सुरक्षित करने में विफलता")
                }
            } catch (e: Exception) {
                onError(e.message ?: "चेकआउट त्रुटि")
            } finally {
                isCheckingOut = false
            }
        }
    }

    // Product Management
    fun saveProduct(product: Product, onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.saveProduct(product)
            showToast("उत्पाद सुरक्षित हुआ: ${product.name}")
            onComplete()
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            showToast("हटाया गया उत्पाद: ${product.name}")
        }
    }

    fun updateStock(productId: String, newStock: Double) {
        viewModelScope.launch {
            repository.updateStock(productId, newStock)
            showToast("स्टॉक अपडेट हुआ")
        }
    }

    // Customer Management
    fun saveCustomer(customer: Customer, onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.saveCustomer(customer)
            showToast("ग्राहक सुरक्षित हुआ: ${customer.name}")
            onComplete()
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
            showToast("ग्राहक हटाया गया: ${customer.name}")
        }
    }

    /**
     * Records payment from customer against outstanding Udhar.
     * Decreases balance atomically and records payment ledger; does NOT create a new sale.
     */
    fun recordCustomerPayment(
        customerId: String,
        amount: Double,
        paymentMode: String,
        notes: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.recordCustomerPayment(customerId, amount, paymentMode, notes)
            result.onSuccess {
                showToast("✓ ₹${MoneyUtil.format(amount)} का भुगतान दर्ज हुआ! बकाया अपडेट हुआ।")
                onComplete()
            }.onFailure { err ->
                showToast("भुगतान दर्ज करने में त्रुटि: ${err.message}")
            }
        }
    }

    // Cloud Sync
    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    fun syncCloud(onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            _isSyncing.value = true
            val result = repository.syncWithFirestore()
            _isSyncing.value = false
            result.onSuccess { msg ->
                showToast(msg)
                onResult(true, msg)
            }.onFailure { err ->
                val msg = err.message ?: "सिंक त्रुटि"
                showToast(msg)
                onResult(false, msg)
            }
        }
    }

    // Backup & Restore
    fun exportBackup(onResult: (String) -> Unit) {
        viewModelScope.launch {
            val json = repository.exportBackupJson()
            onResult(json)
        }
    }

    fun restoreBackup(json: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val res = repository.restoreBackupJson(json)
            res.onSuccess { msg ->
                showToast(msg)
                onResult(true, msg)
            }.onFailure { err ->
                val msg = "रीस्टोर विफल: ${err.message}"
                showToast(msg)
                onResult(false, msg)
            }
        }
    }

    // Settings
    fun updateSettings(updated: ShopSettings) {
        settingsManager.saveSettings(updated)
        showToast("सेटिंग्स सहेजी गईं!")
    }
}
