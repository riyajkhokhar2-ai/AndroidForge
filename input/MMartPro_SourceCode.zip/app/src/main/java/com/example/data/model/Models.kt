package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.util.MoneyUtil
import java.util.UUID

enum class DiscountType {
    FIXED,      // Fixed amount in Rupees (₹)
    PERCENTAGE  // Percentage (%)
}

@Entity(
    tableName = "products",
    indices = [Index(value = ["barcode"], unique = false)]
)
data class Product(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val hindiName: String = "",
    val barcode: String,
    val category: String = "General",
    val unit: String = "Pcs", // Pcs, Kg, Ltr, Pkt, etc.
    val mrp: Double,
    val sellingPrice: Double,
    val costPrice: Double = 0.0,
    val currentStock: Double = 0.0,
    val minStockAlert: Double = 5.0,
    val updatedAt: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false,
    val ownerId: String = ""
) {
    val safeMrp: Double get() = MoneyUtil.round(mrp.coerceAtLeast(0.0))
    val safeSellingPrice: Double get() = MoneyUtil.round(sellingPrice.coerceAtLeast(0.0))
    val savingsPerUnit: Double get() = MoneyUtil.round((safeMrp - safeSellingPrice).coerceAtLeast(0.0))
    val discountPercent: Int get() = if (safeMrp > 0) (((safeMrp - safeSellingPrice) / safeMrp) * 100).toInt().coerceAtLeast(0) else 0
    val isLowStock: Boolean get() = currentStock <= minStockAlert
}

@Entity(
    tableName = "customers",
    indices = [Index(value = ["phone"], unique = false)]
)
data class Customer(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val phone: String,
    val address: String = "",
    val totalCreditDue: Double = 0.0, // Outstanding Udhar balance
    val totalPurchases: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false,
    val ownerId: String = ""
) {
    val safeTotalCreditDue: Double get() = MoneyUtil.round(totalCreditDue.coerceAtLeast(0.0))
    val safeTotalPurchases: Double get() = MoneyUtil.round(totalPurchases.coerceAtLeast(0.0))
}

data class CartItem(
    val product: Product,
    var quantity: Double = 1.0,
    var customPrice: Double? = null
) {
    val safeQuantity: Double get() = quantity.coerceAtLeast(0.01)
    val unitPrice: Double get() = MoneyUtil.round(customPrice?.coerceAtLeast(0.0) ?: product.safeSellingPrice)
    val mrpTotal: Double get() = MoneyUtil.calculateItemTotal(safeQuantity, product.safeMrp)
    val itemTotal: Double get() = MoneyUtil.calculateItemTotal(safeQuantity, unitPrice)
    val itemSavings: Double get() = MoneyUtil.round((mrpTotal - itemTotal).coerceAtLeast(0.0))
}

data class BillItem(
    val productId: String,
    val productName: String,
    val hindiName: String = "",
    val barcode: String = "",
    val unit: String = "Pcs",
    val mrp: Double,
    val unitPrice: Double,
    val quantity: Double,
    val totalAmount: Double,
    val savings: Double
)

@Entity(
    tableName = "bills",
    indices = [
        Index(value = ["billNumber"], unique = true),
        Index(value = ["customerId"])
    ]
)
data class Bill(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val billNumber: String,
    val customerId: String? = null,
    val customerName: String = "Walk-in Customer",
    val customerPhone: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val mrpTotal: Double,
    val subtotal: Double,
    val discountAmount: Double = 0.0,
    val finalAmount: Double,
    val productSavings: Double,
    val totalSavings: Double,
    val amountPaid: Double,
    val balanceDue: Double,
    val paymentMode: String = "CASH", // CASH, UPI, CARD, CREDIT_KHATA, PARTIAL
    val itemsJson: String = "[]",
    val notes: String = "",
    val isSynced: Boolean = false,
    val ownerId: String = ""
) {
    val isFullyPaid: Boolean get() = balanceDue <= 0.01
    val isCreditSale: Boolean get() = balanceDue > 0.01
}

@Entity(
    tableName = "customer_payments",
    indices = [Index(value = ["customerId"])]
)
data class CustomerPayment(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val customerId: String,
    val customerName: String,
    val amount: Double,
    val paymentMode: String = "CASH", // CASH, UPI
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = "",
    val isSynced: Boolean = false,
    val ownerId: String = ""
)

data class ShopSettings(
    val shopName: String = "M Mart Pro",
    val tagline: String = "Supermarket & Daily Needs",
    val address: String = "Shop No. 12, Main Market Road",
    val phone: String = "+91 98765 43210",
    val gstin: String = "27AAAAA0000A1Z5",
    val upiId: String = "mmartpro@upi",
    val receiptFooter: String = "धन्यवाद! Thank you for shopping with us! Please visit again.",
    val isDarkMode: Boolean = false,
    val isHindiDefault: Boolean = false,
    val autoPrint: Boolean = false
)
