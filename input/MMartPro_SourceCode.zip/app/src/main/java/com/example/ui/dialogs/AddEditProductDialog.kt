package com.example.ui.dialogs

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Product
import com.example.ui.components.CameraScannerView
import java.util.UUID

@Composable
fun AddEditProductDialog(
    initialProduct: Product? = null,
    prefilledBarcode: String? = null,
    onSave: (Product) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initialProduct?.name ?: "") }
    var hindiName by remember { mutableStateOf(initialProduct?.hindiName ?: "") }
    var barcode by remember { mutableStateOf(initialProduct?.barcode ?: (prefilledBarcode ?: "")) }
    var category by remember { mutableStateOf(initialProduct?.category ?: "Grocery / किराना") }
    var unit by remember { mutableStateOf(initialProduct?.unit ?: "Pcs") }
    var mrpStr by remember { mutableStateOf(initialProduct?.mrp?.toString() ?: "") }
    var sellingPriceStr by remember { mutableStateOf(initialProduct?.sellingPrice?.toString() ?: "") }
    var costPriceStr by remember { mutableStateOf(initialProduct?.costPrice?.toString() ?: "") }
    var stockStr by remember { mutableStateOf(initialProduct?.currentStock?.toString() ?: "10") }
    var minStockAlertStr by remember { mutableStateOf(initialProduct?.minStockAlert?.toString() ?: "5") }

    var isScanningBarcode by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val mrpVal = mrpStr.toDoubleOrNull() ?: 0.0
    val sellingVal = sellingPriceStr.toDoubleOrNull() ?: 0.0
    val savingsVal = (mrpVal - sellingVal).coerceAtLeast(0.0)
    val discountPercent = if (mrpVal > 0) ((savingsVal / mrpVal) * 100).toInt() else 0

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(20.dp)),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (initialProduct == null) "Add Product / नया उत्पाद" else "Edit Product / उत्पाद बदलें",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                // Inline Camera Scanner if requested
                AnimatedVisibility(visible = isScanningBarcode) {
                    Column(modifier = Modifier.padding(vertical = 8.dp)) {
                        CameraScannerView(
                            onBarcodeScanned = { scanned ->
                                barcode = scanned
                                isScanningBarcode = false
                            },
                            onClose = { isScanningBarcode = false }
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(vertical = 8.dp)
                ) {
                    // Name
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Product Name / उत्पाद का नाम *") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("product_name_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Hindi Name
                    OutlinedTextField(
                        value = hindiName,
                        onValueChange = { hindiName = it },
                        label = { Text("Hindi Name / हिंदी नाम (वैकल्पिक)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Barcode with Scan Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = barcode,
                            onValueChange = { barcode = it },
                            label = { Text("Barcode / बारकोड *") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("product_barcode_input"),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        FilledTonalButton(
                            onClick = { isScanningBarcode = !isScanningBarcode },
                            modifier = Modifier.testTag("scan_product_barcode_btn")
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Scan")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Category & Unit
                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = category,
                            onValueChange = { category = it },
                            label = { Text("Category / श्रेणी") },
                            modifier = Modifier.weight(1.2f),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedTextField(
                            value = unit,
                            onValueChange = { unit = it },
                            label = { Text("Unit / इकाई") },
                            modifier = Modifier.weight(0.8f),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Pricing: MRP & Selling Price
                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = mrpStr,
                            onValueChange = { mrpStr = it },
                            label = { Text("MRP (₹) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("product_mrp_input"),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedTextField(
                            value = sellingPriceStr,
                            onValueChange = { sellingPriceStr = it },
                            label = { Text("Offer Price (₹) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("product_selling_price_input"),
                            singleLine = true
                        )
                    }

                    // Live Savings Badge
                    if (mrpVal > 0 && sellingVal > 0) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (savingsVal > 0) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (savingsVal > 0) "Customer Savings: ₹${"%.2f".format(savingsVal)} ($discountPercent% OFF)" else "No Discount (MRP = Selling Price)",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (savingsVal > 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // Stock & Min Alert
                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = stockStr,
                            onValueChange = { stockStr = it },
                            label = { Text("Current Stock / स्टॉक") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedTextField(
                            value = minStockAlertStr,
                            onValueChange = { minStockAlertStr = it },
                            label = { Text("Min Alert / न्यूनतम") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage ?: "",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel / रद्द करें")
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = {
                            if (name.isBlank()) {
                                errorMessage = "Product name is required / नाम दर्ज करें"
                                return@Button
                            }
                            if (barcode.isBlank()) {
                                errorMessage = "Barcode is required / बारकोड दर्ज करें"
                                return@Button
                            }
                            val mrp = mrpStr.toDoubleOrNull() ?: 0.0
                            val selling = sellingPriceStr.toDoubleOrNull() ?: 0.0
                            if (mrp <= 0 || selling <= 0) {
                                errorMessage = "Enter valid MRP and Selling Price / सही मूल्य दर्ज करें"
                                return@Button
                            }
                            if (selling > mrp) {
                                errorMessage = "Selling price cannot exceed MRP / बिक्री मूल्य MRP से अधिक नहीं हो सकता"
                                return@Button
                            }

                            val stock = stockStr.toDoubleOrNull() ?: 0.0
                            val minAlert = minStockAlertStr.toDoubleOrNull() ?: 5.0
                            val cost = costPriceStr.toDoubleOrNull() ?: 0.0

                            val product = Product(
                                id = initialProduct?.id ?: UUID.randomUUID().toString(),
                                name = name.trim(),
                                hindiName = hindiName.trim(),
                                barcode = barcode.trim(),
                                category = category.trim(),
                                unit = unit.trim(),
                                mrp = mrp,
                                sellingPrice = selling,
                                costPrice = cost,
                                currentStock = stock,
                                minStockAlert = minAlert
                            )
                            onSave(product)
                        },
                        modifier = Modifier.testTag("save_product_btn")
                    ) {
                        Text("Save / सहेजें")
                    }
                }
            }
        }
    }
}
