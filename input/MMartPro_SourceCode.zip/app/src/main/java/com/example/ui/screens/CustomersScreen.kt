package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.ui.MainViewModel
import com.example.ui.dialogs.AddCustomerDialog
import com.example.ui.dialogs.CustomerPaymentDialog
import com.example.ui.dialogs.WhatsAppConfirmDialog
import com.example.util.WhatsAppReminderHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomersScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val customers by viewModel.customers.collectAsState()
    val searchQuery by viewModel.customerSearchQuery.collectAsState()
    val settings by viewModel.settings.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var customerToEdit by remember { mutableStateOf<Customer?>(null) }
    var customerToDelete by remember { mutableStateOf<Customer?>(null) }
    var customerForPayment by remember { mutableStateOf<Customer?>(null) }
    var customerForWhatsAppReminder by remember { mutableStateOf<Customer?>(null) }

    val totalUdhar = customers.sumOf { it.totalCreditDue }
    val customersWithDues = customers.count { it.totalCreditDue > 0.01 }

    // Add / Edit Dialog
    if (showAddDialog || customerToEdit != null) {
        AddCustomerDialog(
            initialCustomer = customerToEdit,
            onSave = { saved ->
                viewModel.saveCustomer(saved) {
                    showAddDialog = false
                    customerToEdit = null
                }
            },
            onDismiss = {
                showAddDialog = false
                customerToEdit = null
            }
        )
    }

    // Payment Repayment Dialog (Decreases balance, does NOT count as sale)
    if (customerForPayment != null) {
        val cust = customerForPayment!!
        CustomerPaymentDialog(
            customer = cust,
            onConfirm = { amount, mode, notes ->
                viewModel.recordCustomerPayment(cust.id, amount, mode, notes) {
                    customerForPayment = null
                }
            },
            onDismiss = { customerForPayment = null }
        )
    }

    // WhatsApp Reminder Confirmation Dialog (Fulfills Rule 9)
    if (customerForWhatsAppReminder != null) {
        val cust = customerForWhatsAppReminder!!
        val message = WhatsAppReminderHelper.buildReminderMessage(
            customerName = cust.name,
            balanceDue = cust.totalCreditDue,
            shopName = settings.shopName,
            shopPhone = settings.phone,
            upiId = settings.upiId
        )
        WhatsAppConfirmDialog(
            customer = cust,
            messageText = message,
            onConfirm = {
                WhatsAppReminderHelper.openWhatsAppChat(context, cust.phone, message)
                customerForWhatsAppReminder = null
            },
            onDismiss = { customerForWhatsAppReminder = null }
        )
    }

    // Delete Confirmation
    if (customerToDelete != null) {
        val cust = customerToDelete!!
        AlertDialog(
            onDismissRequest = { customerToDelete = null },
            title = { Text("ग्राहक हटाएं / Delete Customer?") },
            text = { Text("क्या आप निश्चित रूप से '${cust.name}' को हटाना चाहते हैं?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteCustomer(cust)
                        customerToDelete = null
                    }
                ) {
                    Text("Delete / हटाएं")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { customerToDelete = null }) {
                    Text("Cancel / रद्द करें")
                }
            }
        )
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_customer_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Customer")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Khata Summary Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (totalUdhar > 0) Color(0xFFFFEBEE) else Color(0xFFE0F2F1)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "कुल बकाया उधारी / Total Khata Due",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (totalUdhar > 0) Color(0xFFC62828) else Color(0xFF004D40)
                        )
                        Text(
                            text = "₹${"%.2f".format(totalUdhar)}",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (totalUdhar > 0) Color(0xFFC62828) else Color(0xFF004D40)
                        )
                    }
                    Surface(
                        color = if (totalUdhar > 0) Color(0xFFEF9A9A) else Color(0xFF80CBC4),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "$customersWithDues ग्राहक का बकाया",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setCustomerSearchQuery(it) },
                label = { Text("ग्राहक का नाम या फोन नंबर खोजें / Search Customer") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { viewModel.setCustomerSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_customers_list_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (customers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 60.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.People,
                            contentDescription = null,
                            modifier = Modifier.size(56.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "कोई ग्राहक नहीं मिला / No Customers Found",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "नया ग्राहक जोड़ने के लिए '+' बटन दबाएं।",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(customers, key = { it.id }) { customer ->
                        CustomerItemCard(
                            customer = customer,
                            onReceivePayment = { customerForPayment = customer },
                            onSendReminder = { customerForWhatsAppReminder = customer },
                            onEdit = { customerToEdit = customer },
                            onDelete = { customerToDelete = customer }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CustomerItemCard(
    customer: Customer,
    onReceivePayment: () -> Unit,
    onSendReminder: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val hasDues = customer.totalCreditDue > 0.01

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = customer.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "📱 ${customer.phone}" + if (customer.address.isNotBlank()) " • ${customer.address}" else "",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "कुल खरीदारी / Total Bought: ₹${"%.2f".format(customer.totalPurchases)}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                // Balance Badge
                Surface(
                    color = if (hasDues) Color(0xFFFFEBEE) else Color(0xFFE8F5E9),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (hasDues) "बकाया (Udhar)" else "साफ़ (Clear)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (hasDues) Color(0xFFC62828) else Color(0xFF2E7D32)
                        )
                        Text(
                            text = "₹${"%.2f".format(customer.totalCreditDue)}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (hasDues) Color(0xFFC62828) else Color(0xFF2E7D32)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Receive Payment Button
                if (hasDues) {
                    Button(
                        onClick = onReceivePayment,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("receive_payment_btn")
                    ) {
                        Icon(Icons.Default.Paid, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("भुगतान जमा करें", fontSize = 11.sp)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // WhatsApp Reminder Button
                    FilledTonalButton(
                        onClick = onSendReminder,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFF25D366).copy(alpha = 0.15f),
                            contentColor = Color(0xFF1B5E20)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("whatsapp_reminder_btn")
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("WhatsApp", fontSize = 11.sp)
                    }
                } else {
                    Text(
                        text = "✓ खाता पूरी तरह चुकता है",
                        fontSize = 12.sp,
                        color = Color(0xFF2E7D32),
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(18.dp))
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
