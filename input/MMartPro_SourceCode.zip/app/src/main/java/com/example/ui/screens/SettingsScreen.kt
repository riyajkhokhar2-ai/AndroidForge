package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ShopSettings
import com.example.ui.MainViewModel

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val isSyncing by viewModel.isSyncing.collectAsState()

    var shopName by remember(settings) { mutableStateOf(settings.shopName) }
    var tagline by remember(settings) { mutableStateOf(settings.tagline) }
    var address by remember(settings) { mutableStateOf(settings.address) }
    var phone by remember(settings) { mutableStateOf(settings.phone) }
    var gstin by remember(settings) { mutableStateOf(settings.gstin) }
    var upiId by remember(settings) { mutableStateOf(settings.upiId) }
    var receiptFooter by remember(settings) { mutableStateOf(settings.receiptFooter) }
    var isDarkMode by remember(settings) { mutableStateOf(settings.isDarkMode) }
    var autoPrint by remember(settings) { mutableStateOf(settings.autoPrint) }

    var showBackupDialog by remember { mutableStateOf<String?>(null) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var restoreJsonInput by remember { mutableStateOf("") }
    var showGuideDialog by remember { mutableStateOf(false) }

    // Export Backup Dialog
    if (showBackupDialog != null) {
        val json = showBackupDialog!!
        AlertDialog(
            onDismissRequest = { showBackupDialog = null },
            title = { Text("डेटा बैकअप (JSON) / Data Backup Export") },
            text = {
                Column {
                    Text("बैकअप JSON कॉपी करें या सुरक्षित स्थान पर सेव करें:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = json,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("MMartPro_Backup", json)
                        clipboard.setPrimaryClip(clip)
                        viewModel.showToast("✓ Backup JSON copied to clipboard!")
                        showBackupDialog = null
                    }
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Copy JSON / कॉपी करें")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showBackupDialog = null }) {
                    Text("Close / बंद करें")
                }
            }
        )
    }

    // Restore Dialog
    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("डेटा रीस्टोर / Restore Data from JSON") },
            text = {
                Column {
                    Text("यहाँ अपना बैकअप JSON पेस्ट करें:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = restoreJsonInput,
                        onValueChange = { restoreJsonInput = it },
                        placeholder = { Text("{\"version\":1, ...}") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (restoreJsonInput.isNotBlank()) {
                            viewModel.restoreBackup(restoreJsonInput.trim()) { success, msg ->
                                if (success) {
                                    showRestoreDialog = false
                                    restoreJsonInput = ""
                                }
                            }
                        }
                    }
                ) {
                    Text("Restore / रीस्टोर करें")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showRestoreDialog = false }) {
                    Text("Cancel / रद्द करें")
                }
            }
        )
    }

    // Hindi Guide Dialog
    if (showGuideDialog) {
        AlertDialog(
            onDismissRequest = { showGuideDialog = false },
            title = { Text("उपयोग व इंस्टॉलेशन गाइड / M Mart Pro Guide") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = """
1. नया बिल बनाना (Billing):
• 'Start Billing' पर जाएँ। कैमरा स्कैनर से उत्पाद का बारकोड स्कैन करें, या ऊपर बारकोड / नाम टाइप करके जोड़ें।
• उत्पाद का MRP, डिस्काउंट और बचत खुद-ब-खुद स्क्रीन पर दिखेगी।
• ग्राहक का नाम या मोबाइल नंबर चुनें/दर्ज करें।
• भुगतान का प्रकार चुनें: Cash, UPI, Card, या Khata (उधार)।
• 'Save & Print' पर क्लिक करते ही बिल बन जाएगा और प्रिंट/पीडीएफ तैयार हो जाएगा।

2. उधार खाता (Khata Management):
• 'Khata Book' स्क्रीन में सभी ग्राहकों का बकाया देख सकते हैं।
• ग्राहक जब भी पुराना बकाया चुकाए, 'भुगतान जमा करें' दबाएँ। यह बकाया घटाएगा और इसे नई बिक्री नहीं गिनेगा।
• 'WhatsApp' बटन दबाकर ग्राहक को बकाया का सीधा रिमाइंडर मैसेज भेज सकते हैं।

3. क्लाउड सिंक और लैपटॉप ब्राउज़र:
• नीचे 'Sync to Cloud' बटन दबाकर अपने सभी बिल और स्टॉक को फायरबेस पर सिंक करें।
• उसी डेटा को आप अपने लैपटॉप या डेस्कटॉप ब्राउज़र पर 'web/index.html' के ज़रिए भी देख सकते हैं।

4. डेटा बैकअप (Data Safety):
• 'Export Backup' दबाकर कभी भी अपने डेटा का बैकअप ले सकते हैं।
                        """.trimIndent(),
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showGuideDialog = false }) {
                    Text("समझ गया / Got it")
                }
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .padding(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Shop Details Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Store, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "दुकान विवरण / Shop Profile",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = shopName,
                    onValueChange = { shopName = it },
                    label = { Text("Shop Name / दुकान का नाम *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("settings_shop_name")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = tagline,
                    onValueChange = { tagline = it },
                    label = { Text("Tagline / उप-शीर्षक") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Address / दुकान का पता") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("settings_address")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number / मोबाइल नंबर *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("settings_phone")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = gstin,
                    onValueChange = { gstin = it },
                    label = { Text("GSTIN / टैक्स नंबर (वैकल्पिक)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = upiId,
                    onValueChange = { upiId = it },
                    label = { Text("UPI ID (रसीद पर QR कोड के लिए) *") },
                    placeholder = { Text("e.g. mmartpro@upi") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("settings_upi_id")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = receiptFooter,
                    onValueChange = { receiptFooter = it },
                    label = { Text("Receipt Footer / रसीद पाद टिप्पणी") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val updated = settings.copy(
                            shopName = shopName.trim(),
                            tagline = tagline.trim(),
                            address = address.trim(),
                            phone = phone.trim(),
                            gstin = gstin.trim(),
                            upiId = upiId.trim(),
                            receiptFooter = receiptFooter.trim(),
                            isDarkMode = isDarkMode,
                            autoPrint = autoPrint
                        )
                        viewModel.updateSettings(updated)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_settings_btn")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("सेटिंग्स सहेजें / Save Profile", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Preferences Card (Dark Mode, Auto Print)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "प्राथमिकताएँ / Preferences",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("डार्क मोड / Dark Mode", fontWeight = FontWeight.SemiBold)
                        Text("रात के समय आँखों के आराम के लिए", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = isDarkMode,
                        onCheckedChange = {
                            isDarkMode = it
                            viewModel.updateSettings(settings.copy(isDarkMode = it))
                        },
                        modifier = Modifier.testTag("dark_mode_switch")
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("ऑटो प्रिंट / Auto Print Receipt", fontWeight = FontWeight.SemiBold)
                        Text("बिल बनते ही प्रिंटर डायलॉग खोलें", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = autoPrint,
                        onCheckedChange = {
                            autoPrint = it
                            viewModel.updateSettings(settings.copy(autoPrint = it))
                        }
                    )
                }
            }
        }

        // Cloud Synchronization (Firestore)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudSync, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "क्लाउड सिंक / Cloud Synchronization",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "अपने फोन का डेटा क्लाउड फायरबेस पर सिंक करें ताकि लैपटॉप या अन्य फोन से भी दुकान का रिकॉर्ड देखा जा सके।",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        viewModel.syncCloud { success, msg -> }
                    },
                    enabled = !isSyncing,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("sync_cloud_btn")
                ) {
                    if (isSyncing) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("सिंक हो रहा है... / Syncing...")
                    } else {
                        Icon(Icons.Default.CloudSync, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("क्लाउड सिंक करें / Sync Now to Firestore")
                    }
                }
            }
        }

        // Data Backup & Restore
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "डेटा बैकअप व रीस्टोर / Backup & Restore",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "डेटा की सुरक्षा के लिए नियमित बैकअप लें। बैकअप फाइल को कभी भी वापस रीस्टोर किया जा सकता है।",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = {
                            viewModel.exportBackup { json ->
                                showBackupDialog = json
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("export_backup_btn")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export Backup", fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    OutlinedButton(
                        onClick = { showRestoreDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("restore_backup_btn")
                    ) {
                        Icon(Icons.Default.Upload, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Restore JSON", fontSize = 12.sp)
                    }
                }
            }
        }

        // Help & Hindi Guide
        Button(
            onClick = { showGuideDialog = true },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant).let {
                androidx.compose.material3.ButtonDefaults.filledTonalButtonColors()
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(Icons.Default.Info, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("हिंदी यूजर गाइड / Read Hindi Guide", fontWeight = FontWeight.Bold)
        }
    }
}
