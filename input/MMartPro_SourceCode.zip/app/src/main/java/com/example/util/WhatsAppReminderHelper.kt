package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder

object WhatsAppReminderHelper {

    fun buildReminderMessage(
        customerName: String,
        balanceDue: Double,
        shopName: String,
        shopPhone: String,
        upiId: String
    ): String {
        val upiSection = if (upiId.isNotBlank()) "\n\nआप दिए गए UPI ID पर भी सीधे भुगतान कर सकते हैं:\nUPI ID: $upiId" else ""
        return """
प्रिय $customerName जी,

$shopName की ओर से सादर प्रणाम।

आपके खाते का कुल बकाया बिल (Khata / Udhar) ₹${"%.2f".format(balanceDue)} है।
कृपया समय पर भुगतान करने का कष्ट करें।$upiSection

किसी भी प्रश्न के लिए कृपया संपर्क करें: $shopPhone
धन्यवाद!
— $shopName
        """.trimIndent()
    }

    fun openWhatsAppChat(context: Context, phone: String, message: String) {
        // Clean phone number (strip spaces, dashes, ensure country code)
        var cleanPhone = phone.replace("[^0-9]".toRegex(), "")
        if (cleanPhone.length == 10) {
            cleanPhone = "91$cleanPhone"
        }

        val encodedMessage = URLEncoder.encode(message, "UTF-8")
        val url = "https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMessage"

        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(url)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to general browser or intent chooser
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(browserIntent)
        }
    }
}
