package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Bill
import com.example.data.model.Customer
import com.example.data.model.CustomerPayment
import com.example.data.model.Product
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE name LIKE '%' || :query || '%' OR hindiName LIKE '%' || :query || '%' OR barcode LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchProducts(query: String): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE barcode = :barcode LIMIT 1")
    suspend fun getProductByBarcode(barcode: String): Product?

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getProductById(id: String): Product?

    @Query("SELECT * FROM products WHERE currentStock <= minStockAlert ORDER BY currentStock ASC")
    fun getLowStockProducts(): Flow<List<Product>>

    @Query("SELECT COUNT(*) FROM products")
    suspend fun getProductCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(product: Product)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(products: List<Product>)

    @Update
    suspend fun update(product: Product)

    @Delete
    suspend fun delete(product: Product)

    @Query("DELETE FROM products WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("UPDATE products SET currentStock = currentStock - :qty, updatedAt = :timestamp WHERE id = :id")
    suspend fun decrementStock(id: String, qty: Double, timestamp: Long = System.currentTimeMillis()): Int

    @Query("UPDATE products SET currentStock = :newStock, updatedAt = :timestamp WHERE id = :id")
    suspend fun updateStock(id: String, newStock: Double, timestamp: Long = System.currentTimeMillis())

    @Query("SELECT * FROM products")
    suspend fun getAllProductsSnapshot(): List<Product>
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY name ASC")
    fun getAllCustomers(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE name LIKE '%' || :query || '%' OR phone LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchCustomers(query: String): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getCustomerById(id: String): Customer?

    @Query("SELECT * FROM customers WHERE phone = :phone LIMIT 1")
    suspend fun getCustomerByPhone(phone: String): Customer?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(customer: Customer)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(customers: List<Customer>)

    @Update
    suspend fun update(customer: Customer)

    @Delete
    suspend fun delete(customer: Customer)

    // Using MAX(0.0, ...) ensures that payment records cannot accidentally push credit into negative values
    @Query("UPDATE customers SET totalCreditDue = MAX(0.0, totalCreditDue + :amountChange), updatedAt = :timestamp WHERE id = :id")
    suspend fun adjustCreditDue(id: String, amountChange: Double, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE customers SET totalPurchases = totalPurchases + :purchaseAmount, updatedAt = :timestamp WHERE id = :id")
    suspend fun addPurchase(id: String, purchaseAmount: Double, timestamp: Long = System.currentTimeMillis())

    @Query("SELECT * FROM customers")
    suspend fun getAllCustomersSnapshot(): List<Customer>
}

@Dao
interface BillDao {
    @Query("SELECT * FROM bills ORDER BY timestamp DESC")
    fun getAllBills(): Flow<List<Bill>>

    @Query("SELECT * FROM bills WHERE billNumber LIKE '%' || :query || '%' OR customerName LIKE '%' || :query || '%' OR customerPhone LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchBills(query: String): Flow<List<Bill>>

    @Query("SELECT * FROM bills WHERE id = :id LIMIT 1")
    suspend fun getBillById(id: String): Bill?

    @Query("SELECT * FROM bills WHERE billNumber = :billNumber LIMIT 1")
    suspend fun getBillByNumber(billNumber: String): Bill?

    @Query("SELECT * FROM bills WHERE customerId = :customerId ORDER BY timestamp DESC")
    fun getBillsByCustomer(customerId: String): Flow<List<Bill>>

    @Query("SELECT * FROM bills WHERE timestamp >= :startTime AND timestamp <= :endTime ORDER BY timestamp DESC")
    fun getBillsBetween(startTime: Long, endTime: Long): Flow<List<Bill>>

    @Query("SELECT * FROM bills WHERE balanceDue > 0.01 ORDER BY timestamp DESC")
    fun getPendingCreditBills(): Flow<List<Bill>>

    @Query("SELECT billNumber FROM bills ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestBillNumber(): String?

    @Query("SELECT COUNT(*) FROM bills")
    suspend fun getTotalBillsCount(): Int

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(bill: Bill)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(bills: List<Bill>)

    @Update
    suspend fun update(bill: Bill)

    @Delete
    suspend fun delete(bill: Bill)

    @Query("SELECT * FROM bills")
    suspend fun getAllBillsSnapshot(): List<Bill>
}

@Dao
interface CustomerPaymentDao {
    @Query("SELECT * FROM customer_payments WHERE customerId = :customerId ORDER BY timestamp DESC")
    fun getPaymentsForCustomer(customerId: String): Flow<List<CustomerPayment>>

    @Query("SELECT * FROM customer_payments ORDER BY timestamp DESC")
    fun getAllPayments(): Flow<List<CustomerPayment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(payment: CustomerPayment)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(payments: List<CustomerPayment>)

    @Query("SELECT * FROM customer_payments")
    suspend fun getAllPaymentsSnapshot(): List<CustomerPayment>
}
