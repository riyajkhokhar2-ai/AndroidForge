package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.ui.MainViewModel

@Composable
fun InventoryScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val products by viewModel.products.collectAsState()
    val lowStockProducts by viewModel.lowStockProducts.collectAsState()

    var showLowStockOnly by remember { mutableStateOf(false) }
    var productForStockAdjust by remember { mutableStateOf<Product?>(null) }

    val totalCatalogCount = products.size
    val totalStockUnits = products.sumOf { it.currentStock }
    val totalStockValue = products.sumOf { it.currentStock * it.sellingPrice }

    val displayedProducts = if (showLowStockOnly) lowStockProducts else products

    if (productForStockAdjust != null) {
        val prod = productForStockAdjust!!
        var newStockStr by remember { mutableStateOf(prod.currentStock.toString()) }

        AlertDialog(
            onDismissRequest = { productForStockAdjust = null },
            title = { Text("स्टॉक अपडेट करें / Update Stock") },
            text = {
                Column {
                    Text(prod.name, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newStockStr,
                        onValueChange = { newStockStr = it },
                        label = { Text("New Stock / नया स्टॉक (${prod.unit})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val stock = newStockStr.toDoubleOrNull() ?: prod.currentStock
                        viewModel.updateStock(prod.id, stock)
                        productForStockAdjust = null
                    }
                ) {
                    Text("Update / अपडेट")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { productForStockAdjust = null }) {
                    Text("Cancel / रद्द करें")
                }
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Inventory Value Overview Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "इन्वेंट्री मूल्यांकन / Stock Valuation",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("कुल उत्पाद / Items:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$totalCatalogCount", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("कुल इकाइयाँ / Total Qty:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${"%.1f".format(totalStockUnits)}", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("अनुमानित मूल्य / Stock Value:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("₹${"%.2f".format(totalStockValue)}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Toggle Filter
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = !showLowStockOnly,
                onClick = { showLowStockOnly = false },
                label = { Text("सभी उत्पाद / All (${products.size})") }
            )
            FilterChip(
                selected = showLowStockOnly,
                onClick = { showLowStockOnly = true },
                label = { Text("कम स्टॉक चेतावनी / Low Stock (${lowStockProducts.size})") }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (displayedProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 60.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Inventory2,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (showLowStockOnly) "कोई भी उत्पाद कम स्टॉक में नहीं है! ✓" else "कोई उत्पाद नहीं मिला",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(displayedProducts, key = { it.id }) { product ->
                    InventoryItemCard(
                        product = product,
                        onAdjustStock = { productForStockAdjust = product }
                    )
                }
            }
        }
    }
}

@Composable
fun InventoryItemCard(
    product: Product,
    onAdjustStock: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Barcode: ${product.barcode} • Selling: ₹${product.sellingPrice}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "अलर्ट सीमा / Min Alert: ${product.minStockAlert} ${product.unit}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.outline
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Surface(
                    color = if (product.isLowStock) Color(0xFFFFEBEE) else Color(0xFFE8F5E9),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "${product.currentStock} ${product.unit}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (product.isLowStock) Color(0xFFC62828) else Color(0xFF2E7D32),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = onAdjustStock,
                    modifier = Modifier.height(32.dp)
                ) {
                    Text("स्टॉक बदलें", fontSize = 11.sp)
                }
            }
        }
    }
}
