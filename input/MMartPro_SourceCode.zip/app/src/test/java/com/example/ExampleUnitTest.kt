package com.example

import com.example.data.model.CartItem
import com.example.data.model.Customer
import com.example.data.model.Product
import com.example.ui.CartState
import com.example.util.MoneyUtil
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testMoneyUtil_precisionAndRounding() {
        // IEEE 754 floating point precision test: 0.1 + 0.2 = 0.30000000000000004
        val rawSum = 0.1 + 0.2
        val roundedSum = MoneyUtil.round(rawSum)
        assertEquals(0.30, roundedSum, 0.0001)

        // Half-up rounding
        assertEquals(10.55, MoneyUtil.round(10.546), 0.0001)
        assertEquals(10.54, MoneyUtil.round(10.544), 0.0001)

        // Safe multiplication
        val itemAmount = MoneyUtil.calculateItemTotal(3.0, 149.99)
        assertEquals(449.97, itemAmount, 0.0001)

        // Percentage discount
        val tenPercentOf500 = MoneyUtil.calculateDiscount(500.0, 10.0, isPercentage = true)
        assertEquals(50.0, tenPercentOf500, 0.0001)

        // Fixed discount capped at subtotal
        val discountExceedingSubtotal = MoneyUtil.calculateDiscount(100.0, 150.0, isPercentage = false)
        assertEquals(100.0, discountExceedingSubtotal, 0.0001)

        // Negative discount protection
        val negativeDiscount = MoneyUtil.calculateDiscount(100.0, -20.0, isPercentage = false)
        assertEquals(0.0, negativeDiscount, 0.0001)
    }

    @Test
    fun testBillingCalculations_andSavings() {
        val product1 = Product(
            name = "Aashirvaad Atta 5kg",
            barcode = "8901030383822",
            mrp = 280.0,
            sellingPrice = 245.0,
            currentStock = 20.0
        )
        val product2 = Product(
            name = "Maggi 2-Minute Noodles",
            barcode = "8901058852879",
            mrp = 14.0,
            sellingPrice = 12.0,
            currentStock = 50.0
        )

        val item1 = CartItem(product = product1, quantity = 2.0) // Subtotal: 490, MRP: 560, Save: 70
        val item2 = CartItem(product = product2, quantity = 5.0) // Subtotal: 60, MRP: 70, Save: 10

        val cartState = CartState(
            items = listOf(item1, item2),
            discountInput = 50.0,
            isDiscountPercent = false,
            paymentMode = "CASH"
        )

        // 1. MRP Total
        assertEquals(630.0, cartState.mrpTotal, 0.001)

        // 2. Selling Price Subtotal
        assertEquals(550.0, cartState.subtotal, 0.001)

        // 3. Product Savings (MRP - Selling Price)
        assertEquals(80.0, cartState.productSavings, 0.001)

        // 4. Final Payable (Subtotal - Extra Discount: 550 - 50 = 500)
        assertEquals(500.0, cartState.finalPayable, 0.001)

        // 5. Total Customer Savings (Product savings 80 + Extra discount 50 = 130)
        assertEquals(130.0, cartState.totalSavings, 0.001)

        // 6. Paid & Balance Due for Cash
        assertEquals(500.0, cartState.effectiveAmountPaid, 0.001)
        assertEquals(0.0, cartState.balanceDue, 0.001)
        assertEquals(0.0, cartState.changeToReturn, 0.001)
    }

    @Test
    fun testPercentageDiscountCalculations() {
        val product = Product(
            name = "Fortune Basmati Rice 5kg",
            barcode = "8906007289999",
            mrp = 600.0,
            sellingPrice = 500.0
        )
        val item = CartItem(product = product, quantity = 2.0) // Subtotal: 1000.0

        // 10% discount on 1000 = 100
        val cartWithPercent = CartState(
            items = listOf(item),
            discountInput = 10.0,
            isDiscountPercent = true,
            paymentMode = "CASH"
        )

        assertEquals(1000.0, cartWithPercent.subtotal, 0.001)
        assertEquals(100.0, cartWithPercent.billDiscount, 0.001)
        assertEquals(900.0, cartWithPercent.finalPayable, 0.001)
    }

    @Test
    fun testCashChangeToReturn_whenCustomerPaysMore() {
        val product = Product(
            name = "Amul Butter 500g",
            barcode = "8901262010054",
            mrp = 275.0,
            sellingPrice = 260.0
        )
        val item = CartItem(product = product, quantity = 1.0) // 260.0

        // Customer hands a 500 note for 260 bill
        val cart = CartState(
            items = listOf(item),
            paymentMode = "CASH",
            amountPaid = 500.0,
            isAutoCalculatedPaid = false
        )

        assertEquals(260.0, cart.finalPayable, 0.001)
        assertEquals(240.0, cart.changeToReturn, 0.001)
        assertEquals(0.0, cart.balanceDue, 0.001)
    }

    @Test
    fun testPartialPayment_andCreditKhata() {
        val product = Product(
            name = "Fortune Oil 1L",
            barcode = "8906007280014",
            mrp = 155.0,
            sellingPrice = 138.0
        )
        val item = CartItem(product = product, quantity = 10.0) // 1380.0

        // Partial payment: paid 500, balance 880
        val partialState = CartState(
            items = listOf(item),
            paymentMode = "PARTIAL",
            amountPaid = 500.0,
            isAutoCalculatedPaid = false
        )
        assertEquals(1380.0, partialState.finalPayable, 0.001)
        assertEquals(500.0, partialState.effectiveAmountPaid, 0.001)
        assertEquals(880.0, partialState.balanceDue, 0.001)

        // Full credit (Khata)
        val creditState = CartState(
            items = listOf(item),
            paymentMode = "CREDIT_KHATA",
            isAutoCalculatedPaid = false
        )
        assertEquals(1380.0, creditState.finalPayable, 0.001)
        assertEquals(0.0, creditState.effectiveAmountPaid, 0.001)
        assertEquals(1380.0, creditState.balanceDue, 0.001)
    }

    @Test
    fun testCustomerRepayment_doesNotBecomeNegative() {
        val initialDue = 500.0
        val paymentAmount = 600.0 // Customer pays more than due

        // Customer debt should clamp at 0.0 (as enforced in Daos.kt: MAX(0.0, totalCreditDue + :amountChange))
        val newDebt = Math.max(0.0, initialDue - paymentAmount)
        assertEquals(0.0, newDebt, 0.001)
    }

    @Test
    fun testStockSufficiency_validation() {
        val product = Product(
            id = "p-1",
            name = "Chana Dal 1kg",
            barcode = "8901000111222",
            mrp = 90.0,
            sellingPrice = 80.0,
            currentStock = 5.0
        )

        // 4 units requested -> valid
        val validItem = CartItem(product = product, quantity = 4.0)
        assertTrue(validItem.quantity <= product.currentStock)

        // 6 units requested -> insufficient stock
        val invalidItem = CartItem(product = product, quantity = 6.0)
        assertFalse(invalidItem.quantity <= product.currentStock)
    }

    @Test
    fun testBarcodeDebounce_logic() {
        var lastBarcode: String? = null
        var lastScanTime = 0L
        val cooldownMs = 2500L

        fun canAcceptScan(barcode: String, currentTime: Long): Boolean {
            val isSame = barcode == lastBarcode
            val isCooldownActive = (currentTime - lastScanTime) < cooldownMs
            if (isSame && isCooldownActive) {
                return false
            }
            lastBarcode = barcode
            lastScanTime = currentTime
            return true
        }

        // 1st scan of barcode A at t = 1000 -> Accepted
        assertTrue(canAcceptScan("8901058000416", 1000L))

        // 2nd scan of barcode A at t = 2000 (1 second later, within cooldown) -> Rejected (duplicate hold prevention)
        assertFalse(canAcceptScan("8901058000416", 2000L))

        // 3rd scan of barcode B at t = 2500 (different barcode) -> Accepted
        assertTrue(canAcceptScan("8901262010054", 2500L))

        // 4th scan of barcode A at t = 6000 (after cooldown has passed) -> Accepted
        assertTrue(canAcceptScan("8901058000416", 6000L))
    }
}
